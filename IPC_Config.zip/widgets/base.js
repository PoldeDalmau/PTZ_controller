﻿// The signalR Log Levels
const LogLevel = {
    Trace: 0,
    Debug: 1,
    Information: 2,
    Warning: 3,
    Error: 4,
    Critical: 5,
    None: 6
};
const reverseLogLevel = {};
Object.entries(LogLevel).forEach(p => reverseLogLevel[p[1]] = p[0]);

class Logger {
    constructor(level, bufferSize) {
        this.bufferSize = bufferSize;
        this.buffer = new Array();
        this.forgottenMessageCount = 0;
        this.discardOldest = false;
        this.setLevel(level);
    }

    setLevel(level) {
        if (typeof (level) === "string") {
            const requestedLevel = level;
            this.level = LogLevel[level];

            if (this.level === undefined) {
                throw new Error(`LogLevel ${requestedLevel} is not recognised.`);
            }
        } else {
            this.level = level;
        }
    }

    log(logLevel, ...message) {
        if (logLevel < this.level) {
            return;
        }

        message = [`[${new Date().toISOString()}][${reverseLogLevel[logLevel]}]`, ...message];

        // Discard Newest otherwise (by not adding to the buffer)
        if (this.discardOldest) {
            this.buffer.push(message);
            while (this.buffer.length > this.bufferSize) {
                this.buffer = this.buffer.slice(1, this.buffer.length);
                this.forgottenMessageCount++;
            }
        }

        switch (logLevel) {
            case LogLevel.Trace:
            case LogLevel.Debug:
                console.debug(...message);
                break;
            case LogLevel.Information:
                console.info(...message);
                break;
            case LogLevel.Warning:
                console.warn(...message);
                break;
            case LogLevel.Error:
            case LogLevel.Critical:
                console.error(...message);
                break;
            default:
                break;
        }
    }

    drain() {
        let messages = [];
        if (this.forgottenMessageCount > 0) {
            messages.push([`[${new Date().toISOString()}] -`, `The buffer ran out of space and ${this.forgottenMessageCount} messages were discarded.`]);
            this.forgottenMessageCount = 0;
        }

        messages = messages.concat(this.buffer);
        this.buffer = new Array();
        return messages;
    }

    trace(...args) {
        return this.log(LogLevel.Trace, ...args);
    }

    debug(...args) {
        return this.log(LogLevel.Debug, ...args);
    }

    info(...args) {
        return this.log(LogLevel.Information, ...args);
    }

    warn(...args) {
        return this.log(LogLevel.Warning, ...args);
    }

    error(...args) {
        return this.log(LogLevel.Error, ...args);
    }

    critical(...args) {
        return this.log(LogLevel.Critical, ...args);
    }
}


const logger = new Logger(LogLevel.Information, 64);


class Config {
    constructor(logger) {
        this.logger = logger;
        // Base Defaults
        this.baseDefaults = {
            widget: {
                data: {
                    url: "ws://localhost:9000",
                }
            },
            colors: {
                background: 'rgba(26, 26, 26, 0.8)',
                foreground: 'rgba(220, 220, 220, 0.6)',
                positive: 'rgba(0, 220, 0, 0.6)',
                warning: 'rgba(220, 220, 0, 0.6)',
                danger: 'rgba(220, 0, 0, 0.6)',
            },
            logging: {
                level: LogLevel.Information
            }
        };
        this.widgetDefaults = {};
        this.queryParams = new URLSearchParams(window.location.search);

        this.values = null;
        this.doMerge();
    }

    setWidgetDefaults(defaults) {
        this.widgetDefaults = defaults;
        this.doMerge();
    }

    doMerge() {
        let output = {};

        Object.entries(this.baseDefaults).forEach(p => output[p[0]] = p[1]);

        const merge = (src, dest) => {
            Object.entries(src).forEach(p => {
                if (typeof(p[1]) === "object") {
                    merge(p[1], dest[p[0]]);
                } else {
                    dest[p[0]] = p[1];
                }
            });
        }
        merge(this.widgetDefaults, output);

        this.queryParams.forEach((v, k) => {
            const parts = k.split('.');
            let section = output;
            parts.slice(0, parts.length - 1).forEach(p => {
                const parent = section;
                section = section[p];
                if (section === undefined) {
                    parent[p] = {}
                    section = parent[p];
                }
            });
            section[parts[parts.length-1]] = v;
        });

        this.values = output;
        this.logger.info("Merged Config", JSON.stringify(this.values));
    }

    getAll() {
        return this.values;
    }

    get(path, fallback=null) {
        const parts = path.split('.');
        let selected = this.values;
        for(let i = 0; i < parts.length; i++){
            selected = selected[parts[i]];

            if(selected === undefined){
                break;
            }
        }
        logger.debug(`Config Item "${path}" is "${selected}"`);

        if(selected === undefined){
            return fallback;
        }

        return selected;
    }
}

const config = new Config(logger);
logger.setLevel(config.get("logging.level"));

function dataNotArrived(){
    dataExpected = null;
    setConnectionProblem(true);
}

let dataConnection;
let latestData = null;
let dataExpected = null;
function dataConnect() {
    dataConnection = mqtt.connect(config.get("widget.data.url"));
    dataExpected = setTimeout(dataNotArrived, 1000);
    
    dataConnection.on('message', function (topic, message) {
        if(dataExpected){
            clearTimeout(dataExpected);
            dataExpected = null;
        }
		/* Does the message begin with {" and end with } or [{" and end with }]? if so then this is very
		 * likely to be a JSON message which can be decoded directly */
		var jsonMessage = message.length >= 5 &&
			((message[0] === 0x7b && message[1] === 0x22 && message[message.length - 1] === 0x7d) ||
			(message[0] === 0x5b && message[1] === 0x7b && message[2] === 0x22 && message[message.length-2] === 0x7d && message[message.length-1] === 0x5d));
		if (jsonMessage) {
			console.log("Got a JSON Message");
			let decoder = new TextDecoder("utf-8"); 
	        // Using decode method to get string output 
		    let str = decoder.decode(message); 
			return;
		}
        if(dataBlockDefinition === null) {
            console.error("DataBlock Definition has not loaded yet. Data cannot be decoded.");
            return;
        }
        latestData = new DataBlock(dataBlockDefinition, message);
        setConnectionProblem(false);
        dataExpected = setTimeout(dataNotArrived, 1000);
    });

    const errorHandler = (message) => {
        logger.error("dataConnection error", message);
        setConnectionProblem(true);
    };

    dataConnection.on('close', errorHandler);
    dataConnection.on('offline', errorHandler);
    dataConnection.on('disconnect', errorHandler)

    dataConnection.on('error', (error) => {
        errorHandler(error.toString());
    });

    dataConnection.on('connect', function (event) {
        logger.info("dataConnection on connect", event, JSON.stringify(event));
        setConnectionProblem(false);
        dataConnection.subscribe('watchman_datablock');
    });
}


dataConnect();

let connectionProblems = false;
let connectionProblemAlert = null;

function setConnectionProblem(newValue){
    if(connectionProblemAlert === null){
        connectionProblemAlert = document.getElementById('alert-sign');
        if(connectionProblemAlert === null) {
            return;
        }
    }

    if(config.get("widget.preview")){
        connectionProblemAlert.style.visibility = 'hidden';
        return;
    }

    connectionProblems = newValue;
    if(connectionProblemAlert !== null)
    {
        connectionProblemAlert.style.visibility = connectionProblems ? 'visible' : 'hidden';
    }
}


window.addEventListener('error', function(event) {
    logger.error("window Error", event);
});

const COMPONENT_TYPES = {
    STARDUST: "stardust",
    CANVAS2D: "canvas2d",
    THREEJS: "three.js",
    THREEJS_ORTHO: "three.js.orthopgraphic",
    DATA_ONLY: "data-only",
}

const components = [];
let componentType = null;

function registerComponent(klass, type) {
    if (type === undefined || type === null) {
        throw "Type must be specified.";
    }
    if (Object.values(COMPONENT_TYPES).find(t => t === type) === undefined) {
        throw `Unknown Component Type ${type}`;
    }

    if (componentType !== null && type !== componentType) {
        throw `Only a single Component Type can be used. It is currently set to ${componentType}`;
    }

    componentType = type;

    components.push(klass);
}

function registerInstance(inst, type) {
    if (type === undefined || type === null) {
        throw "Type must be specified.";
    }
    if (Object.values(COMPONENT_TYPES).find(t => t === type) === undefined) {
        throw `Unknown Component Type ${type}`;
    }

    if (componentType !== null && type !== componentType) {
        throw `Only a single Component Type can be used. It is currently set to ${componentType}`;
    }

    componentType = type;

    instances.push(inst);
}

var instances = [];

let platform;
let context2d;

function throttle(func, limit) {
    let lastFunc;
    let lastRan;
    return function () {
        const context = this;
        const args = arguments;
        if (!lastRan) {
            func.apply(context, args);
            lastRan = Date.now();
        } else {
            clearTimeout(lastFunc);
            lastFunc = setTimeout(function() {
                    if ((Date.now() - lastRan) >= limit) {
                        func.apply(context, args);
                        lastRan = Date.now();
                    }
                },
                limit - (Date.now() - lastRan));
        }
    }
}

window.onresize = throttle(doResize, 250);

var contextThree = {};

function doResize() {
    var canvas = document.getElementById("canvas");
    var width = window.innerWidth;
    var height = window.innerHeight;

    if (componentType === COMPONENT_TYPES.STARDUST) {
        platform = Stardust.platform("webgl-2d", canvas, width, height);
        platform.pixelRatio = 1.0;
    }

    if (componentType === COMPONENT_TYPES.CANVAS2D) {
        context2d = canvas.getContext("2d");
        canvas.width = width;
        canvas.height = height;
    }

    if (componentType === COMPONENT_TYPES.THREEJS) {
        contextThree.camera = new THREE.PerspectiveCamera(75, width/height, 0.1, 1000);
        contextThree.renderer.setSize(width, height);
    }

    if (componentType === COMPONENT_TYPES.THREEJS_ORTHO) {
        contextThree.camera = new THREE.OrthographicCamera( -1, 1, height/width, -height/width, 1, 1000);
        contextThree.renderer.setSize(width, height);
    }

    if (componentType === COMPONENT_TYPES.STARDUST) {
        for (var i = 0; i < instances.length; i++) {
            // TODO: Get some kind of requested size from the Component
            instances[i].resize(platform, window.innerWidth, window.innerHeight);
        }
    }

    if (componentType === COMPONENT_TYPES.CANVAS2D) {
        for (var i = 0; i < instances.length; i++) {
            // TODO: Get some kind of requested size from the Component
            instances[i].resize(context2d, window.innerWidth, window.innerHeight);
        }
    }

    if (componentType === COMPONENT_TYPES.THREEJS) {
        for (var i = 0; i < instances.length; i++) {
            // TODO: Get some kind of requested size from the Component
            instances[i].resize(contextThree, window.innerWidth, window.innerHeight);
        }
    }

    if (componentType === COMPONENT_TYPES.THREEJS_ORTHO) {
        for (var i = 0; i < instances.length; i++) {
            // TODO: Get some kind of requested size from the Component
            instances[i].resize(contextThree, window.innerWidth, window.innerHeight);
        }
    }
}

window.onload = async function () {
    var canvas = document.getElementById("canvas");
    var width = window.innerWidth;
    var height = window.innerHeight;

    if (componentType === COMPONENT_TYPES.STARDUST) {
        platform = Stardust.platform("webgl-2d", canvas, width, height);
        platform.pixelRatio = 1.0;
    }

    if (componentType === COMPONENT_TYPES.CANVAS2D) {
        canvas.width = width;
        canvas.height = height;
        context2d = canvas.getContext("2d");
    }

    if (componentType === COMPONENT_TYPES.THREEJS) {
        contextThree.scene = new THREE.Scene();
        contextThree.camera = new THREE.PerspectiveCamera(75, width/height, 0.1, 1000);
        contextThree.renderer = new THREE.WebGLRenderer({ alpha: true });
        contextThree.renderer.setSize(width, height);
        document.body.replaceChild(contextThree.renderer.domElement, canvas);
    }

    if (componentType === COMPONENT_TYPES.THREEJS_ORTHO) {
        contextThree.scene = new THREE.Scene();
        contextThree.camera = new THREE.OrthographicCamera( -1, 1, height/width, -height/width, 1, 1000);
        contextThree.renderer = new THREE.WebGLRenderer({ alpha: true });
        contextThree.renderer.setSize(width, height);
        document.body.replaceChild(contextThree.renderer.domElement, canvas);
    }

    function render(timestamp) {
        if(config.get('widget.preview')){
            // Use low frame rate for previews
            setTimeout(render, 100);
            timestamp = performance.now();
        }else {
            // Considered best practice (according to MDN) even though we've not finished rendering
            // Gives the browser time to process the request and schedule callbacks as needed
            requestAnimationFrame(render);
        }

        if (latestData !== null) {
            for (var i = 0; i < instances.length; i++) {
                // TODO: Pass in a data Object instead
                instances[i].update(timestamp, latestData);
            }
            latestData = null;
        }

        if (componentType === COMPONENT_TYPES.STARDUST) {
            platform.clear([0, 0, 0, 0]);
        }

        if (componentType === COMPONENT_TYPES.CANVAS2D) {
            context2d.clearRect(0, 0, canvas.width, canvas.height);
        }

        for (var i = 0; i < instances.length; i++) {
            instances[i].render();
        }
    }

    if (componentType === COMPONENT_TYPES.STARDUST) {
        for (let componentIndex = 0;
            componentIndex < components.length;
            componentIndex++) {
            instances.push(
                new components[componentIndex](platform, width, height));
        }
    }

    if (componentType === COMPONENT_TYPES.CANVAS2D) {
        for (let componentIndex = 0;
            componentIndex < components.length;
            componentIndex++) {
            instances.push(
                new components[componentIndex](context2d, width, height));
        }
    }

    if (componentType === COMPONENT_TYPES.THREEJS) {
        for (let componentIndex = 0;
            componentIndex < components.length;
            componentIndex++) {
            instances.push(
                new components[componentIndex](contextThree, width, height));
        }
    }

    if (componentType === COMPONENT_TYPES.THREEJS_ORTHO) {
        for (let componentIndex = 0;
             componentIndex < components.length;
             componentIndex++) {
            instances.push(
                new components[componentIndex](contextThree, width, height));
        }
    }

    if (componentType === COMPONENT_TYPES.DATA_ONLY) {
        for (let componentIndex = 0;
             componentIndex < components.length;
             componentIndex++) {
            let newComponent = new components[componentIndex]();
            instances.push(newComponent);
            newComponent.load && await newComponent.load();
        }
    }

    render(Date.now());
}

class BaseComponent {
    frameTime = 16.666;

    getFontSize(width, height){
        return Math.sqrt(width * height)/20
    }

    getMargin(width, height){
        return Math.sqrt(width * height)/10
    }

    setupBackground(width, height) {
        const background = document.getElementById('background');
        background.style.width = width + 'px';
        background.style.height = height + 'px';
        background.width = width;
        background.height = height;
        background.style.position = 'fixed';
        background.style.zIndex = "-1";

        this.backgroundContext = background.getContext("2d");
    }

    selectValue(obj, path) {
        return obj.get(path) || 0;
    }
}

// Uncomment this block to have the widgets publish error logs to the "widget-error" MQTT topic
// Or, copy this block into a specific widget to see logs from a single widget
// window.onerror = function() {
//     dataConnection.publish('widget-error', JSON.stringify(arguments));
// }
// console.error = function() {
//     dataConnection.publish('widget-error', JSON.stringify(arguments));
// }
