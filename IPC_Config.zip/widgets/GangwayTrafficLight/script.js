class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdRedLightStatus = config.get("widget.ShowTrafficGreen", null);

    // get HTML elements
    this.redBulb = document.getElementById("red");
    this.greenBulb = document.getElementById("green");
    this.bulbs = [this.redBulb, this.greenBulb];

    this.currentBulb = 0;

    this.colors = ["red", "lime"];
    this.totalBulbs = this.colors.length;
    this.showRedLight;
    this.dummy = 0;
    // only for forcing the traffic light to a certain value
    this.bulbs[1].style.backgroundColor = this.colors[1];
    this.bulbs[0].style.backgroundColor = this.colors[0];
  }

  displaySymbol(nameOfElement, number) {
    nameOfElement.textContent = `${number}\u00B0`;
  }

  update(value, data) {
    this.showRedLight = this.selectValue(data, this.wdRedLightStatus);
  }

  render() {
    this.dummy++;
    if (this.dummy > 2) {
      this.dummy = 0;
    }

    for (let i = 0; i < this.totalBulbs; i++) {
      this.bulbs[i].style.backgroundColor = "black";
    }

    if (this.showRedLight == 1) {
      this.bulbs[1].style.backgroundColor = `rgb(0, 255, 0,${
        0.98 + this.dummy / 200
      })`;
    } else {
      this.bulbs[0].style.backgroundColor = `rgb(255, 0, 0,${
        0.98 + this.dummy / 200
      })`;
    }
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
