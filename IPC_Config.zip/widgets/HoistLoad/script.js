class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        this.wdNameOfWidget = config.get('widget.NameOfWidget', null);

        // get PLC data
        this.wdLoad = config.get('widget.Load', null);
        this.wdOverload = config.get('widget.Overload', null);
        this.wdUnderload = config.get('widget.Underload', null);
        
        // get HTML elements
        this.tableValues = document.getElementById('tableValues');
        this.container = document.getElementById('container');
        this.description = document.getElementById('description');
        this.progressValueLoad = document.getElementById('progressValueLoad');
        this.displaySymbol(this.progressValueLoad, 7000);

        this.displaySymbol(this.progressValueLoad, 0, false);

        this.description = this.wdNameOfWidget;
    }

    displaySymbol(nameOfElement, valueLoad, underloadOrOverload) {
        nameOfElement.textContent = `${valueLoad}`;

        console.log(underloadOrOverload)

        if (underloadOrOverload){
            this.tableValues.style.color = 'red';
            this.tableValues.style.border = '2px solid red';
        }
        else{
            this.tableValues.style.color = 'lime';
            this.tableValues.style.border = '2px solid rgb(0,0,0,0.0)';
        }
    }

    update(value, data)
    {
        let valueLoad = this.selectValue(data, this.wdLoad);
        console.log("load is this value:", valueLoad);
        let overload = this.selectValue(data, this.wdOverload);
        let underload = this.selectValue(data, this.wdUnderload);

        let underloadOrOverload = false;
        if (overload == 1 || underload == 1){
            underloadOrOverload = true;
        }

        this.displaySymbol(this.progressValueLoad, valueLoad, underloadOrOverload);
    }
    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);