class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        // get PLC data
        this.wdBoomAngle = config.get('widget.BoomAngle', null);
        this.wdKnuckleAngle = config.get('widget.KnuckleAngle', null);
        this.wdSlewingAngle = config.get('widget.SlewingAngle', null);
        
        // get HTML elements
        this.progressValueBoom = document.getElementById('progressValueBoom');
        this.progressValueKnuckle = document.getElementById('progressValueKnuckle');
        this.progressValueSlewing = document.getElementById('progressValueSlewing');

        this.displaySymbol(this.progressValueBoom, 0);
        this.displaySymbol(this.progressValueKnuckle, 0);
        this.displaySymbol(this.progressValueSlewing, 0);
    }

    displaySymbol(nameOfElement, number) {
        nameOfElement.textContent = `${number}\u00B0`;        
    }

    update(value, data)
    {
        // console.log(data)
        let valueBoom = this.selectValue(data, this.wdBoomAngle);
        let valueKnuckle = this.selectValue(data, this.wdKnuckleAngle);
        let valueSlewing = this.selectValue(data, this.wdSlewingAngle);
        
        this.displaySymbol(this.progressValueBoom, valueBoom);
        this.displaySymbol(this.progressValueKnuckle, valueKnuckle);
        this.displaySymbol(this.progressValueSlewing, valueSlewing);
    }
    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);