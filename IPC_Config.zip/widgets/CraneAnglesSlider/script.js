class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdAngleLuffing = config.get("widget.AngleLuffing", null);
    this.wdAngleFolding = config.get("widget.AngleFolding", null);
    this.wdAngleSlewing = config.get("widget.AngleSlewing", null);

    // get HTML elements
    // this.progressValueBoom = document.getElementById('progressValueBoom');
    // this.progressValueKnuckle = document.getElementById('progressValueKnuckle');
    // this.progressValueSlewing = document.getElementById('progressValueSlewing');

    this.pointerLineLuffing = document.getElementById("pointerLineLuffing");
    this.triangleFolding = document.getElementById("pointerLineFolding");
    this.triangleSlewing = document.getElementById("pointerLineSlewing");

    this.angleLuffing = document.getElementById("angleLuffing");
    this.angleFolding = document.getElementById("angleFolding");
    this.angleSlewing = document.getElementById("angleSlewing");

    this.contLuffing = document.getElementById("containerLuffing");
    this.contFolding = document.getElementById("containerFolding");
    this.contSlewing = document.getElementById("containerSlewing");

    this.progBarLuffing = document.getElementById("progressBarLuffing");
    this.progBarFolding = document.getElementById("progressBarFolding");
    this.progBarSlewing = document.getElementById("progressBarSlewing");

    this.namesContainers = [
      "containerLuffing",
      "containerFolding",
      "containerSlewing",
    ];

    this.colorsBar = ["red", "orange", "green", "orange", "red"]

    // referencres to cointainers
    this.refContainers = [this.contLuffing, this.contFolding, this.contSlewing];
    this.refProgressBars = [this.progBarLuffing, this.progBarFolding, this.progBarSlewing];

    this.widthBarsLuffing = [10, 20, 40, 20, 10]
    this.widthBarsFolding = [20, 20, 20, 20, 20]
    this.widthBarsSlewing = [20, 20, 20, 20, 20]
    this.refWidthBars = [this.widthBarsLuffing, this.widthBarsFolding, this.widthBarsSlewing];

    this.rangesProgLuffing = [];
    this.rangesProgLuffing = [];
    this.rangesCointainer = [this.rangesContLuffing]

    this.AddColorBlocks();
    this.AddBlackBars();

    this.rangeStart = -8;
    this.rangeEnd = 90;

    this.posLuffing = 20;
    this.posFolding = 40;
    this.posSlewing = 90;

    this.valueLuffing = 40;
    this.valueFolding = 20;
    this.valueSlewing = 90;

    this.Draw();
  }

  AddColorBlocks() {
    let firstPos = 0;
    for (let j = 0; j < 3; j++) {
      firstPos = 0;
      for (let i = 0; i < 5; i++) {
        let varName = `node${i}TEST${this.namesContainers[j]}`;
        const node = document.createElement(varName);
        node.style.position = "absolute";
        node.style.top = `${0}px`;
        node.style.width = `${this.refWidthBars[j][i]}px`;
        node.style.height = `${20}px`;
        node.style.left = `${firstPos}px`;
        firstPos += this.refWidthBars[j][i];
        node.style.backgroundColor = this.colorsBar[i];
        this.refProgressBars[j].appendChild(node);
      }
    }
  }

  AddBlackBars() {
    let firstPos = 5;
    for (let j = 0; j < 3; j++) {
      firstPos = 5;
      for (let i = 0; i < 7; i++) {
        let varName = `node${i}TEST${this.namesContainers[j]}`;
        const node = document.createElement(varName);
        node.style.position = "absolute";
        node.style.top = `${12}px`;
        node.style.width = `${1}px`;
        node.style.height = `${20}px`;
        node.style.left = `${firstPos}px`;
        firstPos += 15;
        node.style.backgroundColor = "black";
        this.refContainers[j].appendChild(node);
      }
    }
  }

  UpdateProgressBar(){

  }

  Draw() {
    this.pointerLineLuffing.style.left = `${20}px`;

    this.angleLuffing.textContent = this.valueLuffing + " °";

    this.triangleFolding.style.left = `${this.posFolding}px`;
    this.angleFolding.textContent = this.valueFolding + " °";

    this.triangleSlewing.style.left = `${this.posSlewing}px`;
    this.angleSlewing.textContent = this.valueSlewing + " °";
  }

  update(value, data) {
    this.posLuffing = this.selectValue(data, this.wdAngleLuffing);
    this.posFolding = this.selectValue(data, this.wdAngleFolding);
    this.posSlewing = this.selectValue(data, this.wdAngleSlewing);

    this.valueLuffing = (100 / 90) * this.posSlewing;
    this.valueFolding = (100 / 90) * this.posFolding;
    this.valueSlewing = (100 / 90) * this.posSlewing;

    this.Draw();
  }

  render() {}
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
