class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        // get PLC data
        this.wdWirePayout = config.get('widget.WirePayout', null);
        
        // get HTML elements
        this.progressValueWirePayout = document.getElementById('progressValueWirePayout');

        this.displaySymbol(this.progressValueWirePayout, 0);
    }

    displaySymbol(nameOfElement, number) {
        nameOfElement.textContent = `${number}`;        
    }

    update(value, data)
    {
        let valueLoad = this.selectValue(data, this.wdWirePayout);
        this.displaySymbol(this.progressValueWirePayout, valueLoad);
    }
    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);