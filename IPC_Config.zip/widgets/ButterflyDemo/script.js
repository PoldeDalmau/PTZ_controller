class Component extends BaseComponent {
    constructor(context, width, height) {
        super();
        //get plc data. 'widget.Data' is  taken from plc_data_block.json.
        // this.dataValuePath = config.get('widget.Data', null);
        

        this.images = ["ternarycontour.png", "safeWorkingLoadChart.png", "genie-load-chart.jpg", "jlg-load-chart.jpg"]
        // this.switchButton = document.getElementById('clickme');
        this.image = document.getElementById('image');
        this.cross = document.getElementById('cross');
        this.bar = document.getElementById('bar');
        this.barContainer = document.getElementById('barContainer');
        this.marks = document.getElementById('marks');

        // this.xSlider = document.getElementById('xSlider');
        // this.ySlider = document.getElementById('ySlider');
        // this.barSlider = document.getElementById('barSlider');
        // this.loadSlider = document.getElementById('maxLoad');
        this.x = 0;
        this.y = 50;
        this.barValue = 0; // Initial bar fill value
        this.limitLoad = 0;
        this.imageIndex = 0;
        // this.switchButton.addEventListener("click", () => {
            // var img = document.getElementById("image");
            // this.imageIndex = (this.imageIndex + 1) % this.images.length;
            // img.src=this.images[this.imageIndex];
        // });

        // this.xSlider.addEventListener('input', () => {
        //     this.x = this.xSlider.value / 100 * this.image.width;
        //     this.updateCross();
        // });

        
        // this.ySlider.addEventListener('input', () => {
        //     this.y = (1 - this.ySlider.value / 100) * this.image.width;
        //     this.updateCross();
        // });

        // this.loadSlider.addEventListener('input', () => {
        //     this.limitLoad = 100 - this.loadSlider.value;
        //     // this.barValue = this.barSlider.value * this.loadSlider.value/100; //
        //     this.updateLimitLoad();
        //     // this.updateBar(); //
        // });

        // this.barSlider.addEventListener('input', () => {
        //     // this.barValue = this.barSlider.value * this.loadSlider.value/100;
        //     this.barValue = this.barSlider.value;
        //     this.updateBar();
        // });


        this.image.onload = () => {
            this.updateCross(); // Draw initial state
            this.updateBar(); // Draw initial state
            this.updateLimitLoad();
        };

        // demo
        this.increasing = true;
        this.demo();
        this.setupInterval();


    };


    updateCross() {
        // Update the position of the cross
        let crossX = this.x - 20; // Adjust for half the cross size
        let crossY = this.y - 20; // Adjust for half the cross size
        this.cross.style.left = `${crossX}px`;
        this.cross.style.top = `${crossY}px`;
    }

    updateLimitLoad(){
        const triangle = document.getElementById('triangle');
        // triangle.style.left = '100px'
        triangle.style.top = `${this.limitLoad}%`;
    }

    updateBar() {
        // Padding from the top and bottom in pixels
        const paddingTop = 75;
        const paddingBottom = 20;

        // Set the container's dimensions to match the available height
        const availableHeight = this.image.height - paddingTop - paddingBottom;
        this.barContainer.style.height = `${availableHeight}px`;
        this.barContainer.style.top = `${paddingTop}px`;

        // Calculate the height of the bar based on the slider value
        const barHeight = this.barValue / 100 * availableHeight;
        this.bar.style.height = `${barHeight}px`;

        console.log(this.barValue / (100 - this.limitLoad));
        if(this.barValue / (100 - this.limitLoad) > 0.8)
            {this.bar.style.backgroundColor = 'red';}
        else if(this.barValue / (100 - this.limitLoad) < 0.8)
            {this.bar.style.backgroundColor = 'limegreen';}
        // Clear existing marks
        this.marks.innerHTML = '';
        
        // Add marks at every 10% interval
        for (let i = 0; i <= 100; i++) {
            this.addMark(i);
        }
    }

    addMark(percentage) {
        const mark = document.createElement('div');
        mark.className = 'mark';
        const containerHeight = this.barContainer.clientHeight;
        const markPosition = (percentage / 100) * containerHeight;
        mark.style.bottom = `${markPosition}px`;
        if (percentage % 10 == 0){
            if(percentage == 0 || percentage == 100){ // don't draw mark for min and max value
                mark.style.width = '0px';
                mark.style.height = '0px';
            } else{
                mark.style.width = '15px';            // make thicker if multiple of 10
                mark.style.height = '2px';
            }
            const text = document.createElement('span');
            text.innerText = percentage/* + '%'*/; // Display percentage value as text
            text.style.position = 'relative'; // Set position to relative for text positioning
            text.style.color = 'limegreen';
            text.style.left = '30px'; // Adjust left offset for text
            text.style.bottom = '10px'; // Adjust up offset for text
            mark.appendChild(text); // Append text to mark element
            
        } 
        this.marks.appendChild(mark);
    }

    update(value, data) {
        // Update function logic
    }

    render() {
        // Render function logic
    }


    demo() 
    {
        if (this.increasing) 
        {
            this.barValue++;

            this.limitLoad++;
            this.imageIndex ++;

            if(this.limitLoad % 30 == 0){
                var img = document.getElementById("image");
                this.imageIndex = (this.imageIndex + 1) % this.images.length;
                img.src=this.images[Math.round(this.imageIndex)];
            }

            if (this.barValue >= 100) 
            {
                this.increasing = false;
            }
        } else 
        {
            // this.x -= 5;
            // this.y -= 5;
            this.barValue--;
            this.limitLoad--;


            if (this.barValue <= 0) 
                {
                    this.increasing = true;
                }
            }
        this.x = 100 + 100*Math.cos(this.barValue/10);
        this.y = 100 + 100*Math.sin(this.barValue/10);
        this.updateCross();
        this.updateBar();
        this.updateLimitLoad();
    }

    setupInterval()
    {
        setInterval(() => {this.demo();},100);
    }

}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);