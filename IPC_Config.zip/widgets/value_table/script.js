﻿class Component extends BaseComponent {
    constructor(context, width, height) {
        super();
        this.orientation = 'left';
        
        this.column_headers = [
            {
                "id": 1,
                "title": "Left",
                "ratio": 2.0
            },
            {
                "id": 2,
                "title": "Centre\nColumn",
                "ratio": 5.0
            },
            "line",
            {
                "id": 3,
                "title": "Right",
                "lines": 1
            }
        ];
        this.rows = [
            "line",
            {
                1:"Basic Label",
                2: {"selector": "a.b.c", "prefix": "£", "suffix": " GBP"},
                3: "Multi\nLine"
            }
        ];

        this.resize(context, width, height);
    }
    
    resize(context, width, height) {
        this.width = width;
        this.height = height;
        this.context = context;

        this.setupBackground(window.innerWidth, window.innerHeight);

        this.headerfont = "bold 20px Sans-serif";
        this.headerStyle = config.get('colors.foreground', config.get('widget.foregroundColor', 'white'));

        this.lineStyle = config.get('colors.foreground', config.get('widget.foregroundColor', 'white'));
        this.lineWidth = 3;
        this.lineHeight = 20;

        // Render the background
        this.backgroundContext.fillStyle = config.get('colors.background', config.get('widget.backgroundColor', 'black'));
        this.backgroundContext.beginPath();
        this.backgroundContext.rect(0, 0, window.innerWidth, window.innerHeight);
        this.backgroundContext.fill();

        this.renderHeaders()
    }

    // TODO: Change this to accept a Object full of data & select the appropriate part(s)
    update(value, data) {
        this.v = (data.orientationAbsolute || {}).alpha || 0;
        this.z = (data.orientationAbsolute || {}).beta || 0;

        this.latestData = {
            a: {
                b: {
                    c: 123
                }
            }
        }
    }

    getSelected(path){
        const parts = path.split('.');
        let obj = this.latestData;

        for(let i=0; i < parts.length; i++){
            if(parts[i] === ''){
                continue;
            }

            obj = obj[parts[i]];
        }

        return obj;
    }

    fillMultiLineText(context, text, x, y, options){
        options = options || {};
        const lines = text.split('\n');
        const lineHeight = options.lineHeight || this.lineHeight;

        const y_top = y - ((lines.length/2 - 0.5) * lineHeight);

        // TODO: Different Aligns & Baselines
        for(let i = 0; i < lines.length; i++){
            const line = lines[i];
            const line_y = y_top + (i * lineHeight);

            context.fillText(line, x, line_y)
        }
    }

    renderHeaders(){
        const context = this.backgroundContext;
        let x = 0;
        let totalRatio = 0;
        let allocatedLines = 0;
        for(let i = 0; i < this.column_headers.length; i++){
            const header = this.column_headers[i];
            if(typeof(header) === "object"){
                totalRatio += header.ratio || 1;
                allocatedLines = Math.max(allocatedLines, (header.lines || header.title.split('\n').length) + 1);
            }
        }
        this.headerHeight = allocatedLines * this.lineHeight;

        for(let i = 0; i < this.column_headers.length; i++){
            const header = this.column_headers[i];

            if(typeof(header) === 'string' && header === 'line'){
                context.strokeStyle = this.lineStyle;
                context.lineWidth = this.lineWidth;
                context.beginPath();
                context.moveTo(x, 0);
                context.lineTo(x, this.height);
                context.stroke();
                continue;
            }

            if(typeof(header) === "object"){
                const headerWidth = this.width * ((header.ratio || 1) / totalRatio);
                context.fillStyle = this.headerStyle;
                context.font = this.headerfont;
                context.textAlign = 'center';
                context.textBaseline = 'middle';

                this.fillMultiLineText(context, header.title, x + headerWidth/2, this.headerHeight/2);

                header._left = x;
                header._width = headerWidth;

                x += headerWidth;
            }
        }
    } 

    getHeader(id){
        for(let i = 0; i < this.column_headers.length; i++){
            const header = this.column_headers[i];
            if(typeof(header) === "object" && (header.id.toString() === id.toString() || header.title.toString() === id.toString())){
                return header;
            }
        }

        return null;
    }

    getCellText(cell){
        // TODO: Cell text from selector/update
        if(typeof(cell) === 'string'){
            return cell;
        }
        if(typeof(cell) == 'object'){
            let text = '';
            if('selector' in cell){
                text = this.getSelected(cell.selector);
            }else{
                text = cell.text;
            }

            if('prefix' in cell){
                text = cell.prefix + text;
            }
            if('suffix' in cell){
                text = text + cell.suffix;
            }

            return text;
        }
        return 'Unknown Cell ' + cell
    }

    renderRows(){
        const context = this.context;
        let y = this.headerHeight;
        for(let i = 0; i < this.rows.length; i++){
            const row = this.rows[i];

            if(typeof(row) === 'string' && row === 'line'){
                context.strokeStyle = this.lineStyle;
                context.lineWidth = this.lineWidth;
                context.beginPath();
                context.moveTo(0, y);
                context.lineTo(this.width, y);
                context.stroke();
                continue;
            }

            if(typeof(row) === "object"){
                let rowHeight = 0;
                const cells = Object.keys(row);
                const lineHeight = this.lineHeight;

                for(let j = 0; j < cells.length; j++){
                    if(typeof(cells[i]) === 'string' && ['lines'].indexOf(cells[i]) >= 0){
                        continue;
                    }

                    const cell = row[cells[j]];
                    const cellText = this.getCellText(cell);

                    rowHeight = Math.max(rowHeight, (((cell.lines || cellText.split('\n').length) + 1) * lineHeight));
                }

                for(let j = 0; j < cells.length; j++){
                    if(typeof(cells[i]) === 'string' && ['lines'].indexOf(cells[i]) >= 0){
                        continue;
                    }

                    const header = this.getHeader(cells[j]);
                    const cell = row[cells[j]];
                    let cellText = this.getCellText(cell);

                    context.fillStyle = this.rowStyle;
                    context.font = this.rowFont;

                    if(typeof(cell) === 'string'){
                        cellText = cell;

                        context.textAlign = 'center';
                        context.textBaseline = 'middle';
                    }

                    this.fillMultiLineText(context, cellText, header._left + header._width/2, y + rowHeight/2);
                }

                y += rowHeight;
            }
        }
    }

    render() {
        this.rowFont = this.headerfont;
        this.rowStyle = this.headerStyle;

        this.renderRows()
    }
}

registerComponent(Component, COMPONENT_TYPES.CANVAS2D);