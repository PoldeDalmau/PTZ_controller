class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdText = config.get("widget.Text", null);
    this.wdValue = config.get("widget.Value", null);
    this.wdUnit = config.get("widget.Unit", null);

    // css data
    this.scalingFactor = getComputedStyle(document.body).getPropertyValue('--scaling');
    
    // html
    this.htmlText = document.getElementById("description");
    this.htmlUnit = document.getElementById("valueAndUnit");

    this.unit = this.wdUnit;

    this.UpdateText(this.wdText);
    this.UpdateValueAndUnit(120, "kg");
    
    //testing
    // this.UpdateText("dnabhd jnn");
    // this.UpdateValueAndUnit(100, "kg");
  }
  
  UpdateValueAndUnit(value, unit){
    this.htmlUnit.innerText = value + " " + unit;
  }

  UpdateText(name){
    this.htmlText.innerText = name;
  }
  
  update(value, data) {
    this.UpdateValueAndUnit((this.selectValue(data, this.wdValue)), this.unit);
  }

  render() {
    // Render function logic
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
