class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdLineHor = config.get("widget.LineHor", null);
    this.wdLineVer = config.get("widget.LineVer", null);

    this.images = [
      "loadchart_01_transparent.png",
      "loadchart_point2_Deck Lift_6t.png",
      "loadchart_point2_Ship to fixed Lift_6t.png",
      "loadchart_point3_Ship2Ship Lift_1.5t.png",
      "loadchart_point4_Ship2Ship Lift_2t.png",
      "loadchart_point8_Ship to fixed Lift_6t.png",
      "loadchart_point9_Harbour Lift_6t.png",
      "loadchart_point12_Deck Lift_12t.png",
      "loadchart_point12_Harbour Lift_12t.png",
    ];

    this.SWLs = [6, 6, 6, 1.5, 2, 6, 6, 12, 12];

    // this.switchButton = document.getElementById('clickme');
    this.image = document.getElementById("image");
    this.triangle = document.getElementById("triangle");
    this.lineHor = document.getElementById("lineHor");
    this.lineVer = document.getElementById("lineVer");
    this.container = document.getElementById("container");
    // this.bar = document.getElementById('bar');
    // this.barContainer = document.getElementById('barContainer');
    // this.marks = document.getElementById('marks');

    this.x = 13; // radius of crane [m]
    this.y = -4; // lower boomhead sheave axis height [m] relative to slew
    this.maxRoC = 40; // maximum radius of crane [m]
    this.maxLBSAH = 30; // maximum Lower Boomhead Sheave Axis Height [m]
    // this.barValue = 0; // Initial bar fill value
    this.currentLoad = 1.5;
    this.imageIndex = 0;

    var img = document.getElementById("image");
    img.src= "./Reel_pngs/" + this.images[Math.round(this.imageIndex)];

    this.image.onload = () => {
      this.updateCross(); // Draw initial state
      this.updatecurrentLoad();
    };
  }

  updateCross() {
    // Update the position of the cross
    this.lineHor.style.top = `${70}px`;
    this.lineVer.style.left = `${120}px`;
  }

  update(value, data) {
    this.valLineHor = this.selectValue(data, this.wdLineHor);
    this.valLineVer = this.selectValue(data, this.wdLineVer);

    this.lineHor.style.top = `${this.valLineHor}px`;
    this.lineVer.style.left = `${this.valLineVer}px`;
  }

  render() {
    // Render function logic
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
