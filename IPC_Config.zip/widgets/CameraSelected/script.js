class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        //Config data
        this.wdNumberOfCam = config.get('widget.NumberOfCamera', null);

        // get PLC data
        this.wdCameraSelected = config.get('widget.CameraSelected', null);
        
        // get HTML elements
        this.blinkingImage = document.getElementById('imgZoom');

        this.dummy = 0;

        // this.blinkingImage.style.opacity = 0 + this.dummy/200;
    }

    displaySymbol(nameOfElement, number) {
        nameOfElement.textContent = `${number}\u00B0`;        
    }

    update(value, data)
    {
        this.dummy++;
        if (this.dummy > 2) {
            this.dummy = 0;
        }
        
        let showFrame = this.selectValue(data, this.wdCameraSelected);
        this.blinkingImage.style.opacity = 0.0 + this.dummy/300;

        if ((showFrame) == this.wdNumberOfCam){
            this.blinkingImage.style.opacity = 0.98 + this.dummy/200;
        }
    }

    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);