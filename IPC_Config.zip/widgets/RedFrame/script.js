class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        //Config data
        this.wdNumberOfCam = config.get('widget.NumberOfCamera', null);

        // get PLC data
        this.wdRedFrameHighLight = config.get('widget.HighLightFrame', null);
        
        // get HTML elements
        this.borderDiv = document.getElementById('borderDiv');

        this.dummy = 0;
    }

    displaySymbol(nameOfElement, number) {
        nameOfElement.textContent = `${number}\u00B0`;        
    }

    update(value, data)
    {
        this.dummy++;
        if (this.dummy > 2) {
            this.dummy = 0;
        }
        let showFrame = this.selectValue(data, this.wdRedFrameHighLight);
        this.borderDiv.style.border = `10px solid rgb(0,0,0, ${this.dummy/200})`;

        if ((showFrame) == this.wdNumberOfCam){
            this.borderDiv.style.border = `10px solid rgb(255,0,0, ${0.98 + this.dummy/200})`;
        }
    }

    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);