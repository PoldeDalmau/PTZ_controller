﻿class Component extends BaseComponent  {
    constructor(context, width, height) {
        super();
        this.valuePath = config.get('widget.selector', null);

        this.valueDirty = false;
        this.skippedRenders = 0;

        this.resize(context, width, height);
    }
    
    resize(context, width, height) {
        this.fontSize = this.getFontSize(width, height);
        this.margin = this.getMargin(width, height);

        const ratio = width / height;
        if(this.orientation === 'up' || this.orientation === 'down'){
            this.lineWidthVertical = 0.01;
            this.lineWidthHorizontal = this.lineWidthVertical * ratio;
        }else{
            this.lineWidthHorizontal = 0.01;
            this.lineWidthVertical = this.lineWidthHorizontal / ratio;
        }

        this.width = width;
        this.height = height;
        this.context = context;
    }

    update(value, data) {
        if(this.valuePath){
            this.v = this.selectValue(data, this.valuePath);
            this.valueDirty = true;
        }
        //this.z = (data.orientationAbsolute || {}).beta || 0;
    }

    render() {
        const context = this.context;

        context.beginPath();
        context.rect(0, 0, 100, 100);
        context.fillStyle = this.v < 500 ? 'black' : 'white';
        context.fill();

        this.valueDirty = false;
        this.skippedRenders = 0;
    }
}

registerComponent(Component, COMPONENT_TYPES.CANVAS2D);