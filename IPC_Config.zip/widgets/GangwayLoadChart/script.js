class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdCursorHeight = config.get("widget.CursorHeight", null);
    this.wdLuffAngle = config.get("widget.LuffAngle", null);
    this.wdTelescopePosition = config.get("widget.TelescopePosition", null);

    this.image = document.getElementById("image");
    this.container = document.getElementById("container");
    this.cross = document.getElementById("cross");

    // ensuring max and min values coincide with png labels
    this.maxHorCor = 435;
    this.maxVerCor = 324;
    this.minHorCor = 0;
    this.minVerCor = 324;

    // get css variables
    this.marginAboveImage = getComputedStyle(document.documentElement).getPropertyValue('--marginTop');
    
    // get html elements
    this.cursorText = document.getElementById("cursorText");
    this.heightText = document.getElementById("heightText");
    this.radiusText = document.getElementById("radiusText");

    this.basePosLineHor = 220;
    this.basePosLineVer = 200;

    this.valLineHor = 25;
    this.valLineVer = -5;
    
    this.telescopePosition = 0;
    this.cursorHeight = 35595;
    this.bumper = 23000;
    this.offset = 0;
    this.luffAngle = 10;

    this.updateCross();
  }
  
  updateText(height, radius, cursorHeight) {

    this.cursorText.innerHTML = "Cursor: <br>";
    this.cursorText.innerHTML += (this.cursorHeight/1000).toFixed(1);
    this.cursorText.innerHTML += " m";

    this.heightText.innerHTML = "Height: ";
    this.heightText.innerHTML += (height).toFixed(1);
    this.heightText.innerHTML += " m";

    this.radiusText.innerHTML = "Radius: ";
    this.radiusText.innerHTML += (radius).toFixed(1);
    this.radiusText.innerHTML += " m";

  }
  updateCross() {
    let luffAngleRadians = this.luffAngle * Math.PI/180;

    // x-coordinate
    let radius =
      (this.telescopePosition + this.bumper - this.offset)/1000 *
      Math.cos(luffAngleRadians);
    //    +
    //   this.cursorHeight/1000 * this.toDegrees(Math.sin(luffAngleRadians));
    // // y-coordinate
    // let height = 0; 
    let height = 
      (this.telescopePosition + this.bumper - this.offset)/1000 *
      Math.sin(luffAngleRadians);
      //  -
      // this.cursorHeight/1000 * this.toDegrees(Math.sin(luffAngleRadians));
    this.updateText(height, radius, this.cursorHeight);
    this.cross.style.top = `calc(${-height * 58.2 + 300}px + var(--marginTop))`;
    this.cross.style.left = `calc(${(radius - 19) * 63.6 - 125.8}px + var(--marginLeft))`;

    this.cross.style.transform = `rotate(${-this.luffAngle}deg)`;
  }

  toDegrees (angle) {
    return angle * (180 / Math.PI);
  }

  // AddNumbersHor() {
  //   let firstPos = 5;
  //   let firstNumber = 0;

  //   for (let i = 0; i < 7; i++) {
  //     let varName = `number${i}n${firstNumber}`;
  //     const node = document.createElement(varName);
  //     node.style.position = "absolute";
  //     node.style.top = `${5}px`; // scale
  //     node.style.width = `${1}px`;
  //     node.style.height = `${15}px`;
  //     node.style.left = `${firstPos}px`;
  //     node.style.fontSize = `${22}px`;
  //     node.style.fontWeight = "600";
  //     node.style.color = "lime";
  //     node.textContent = firstNumber;
  //     this.lineAsHor.appendChild(node);

  //     firstPos += 70;
  //     firstNumber += 5;
  //   }
  // }

  // AddNumbersVer() {
  //   let firstPos = 6;
  //   let firstNumber = 0;

  //   for (let i = 0; i <= 12; i++) {
  //     let varName = `number${i}n${firstNumber}`;
  //     const node = document.createElement(varName);
  //     node.style.position = "absolute";
  //     node.style.bottom = `${firstPos}px`;
  //     node.style.height = `${15}px`;
  //     node.style.left = `${-35}px`;
  //     node.style.fontSize = `${22}px`;
  //     node.style.fontWeight = "600";
  //     node.style.color = "lime";
  //     node.textContent = firstNumber;
  //     node.style.textAlign = "right";
  //     this.lineAsVer.appendChild(node);

  //     firstPos += 78;
  //     firstNumber += 5;
  //   }
  // }

  update(value, data) {
    this.cursorHeight = this.selectValue(data, this.wdCursorHeight);
    this.luffAngle = this.selectValue(data, this.wdLuffAngle);
    this.telescopePosition = this.selectValue(data, this.wdTelescopePosition);

    this.updateCross();
  }

  render() {
    // Render function logic
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
