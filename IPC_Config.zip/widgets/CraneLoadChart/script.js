class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdRaduisPosition = config.get("widget.RaduisPosition", null);
    this.wdHeightPosition = config.get("widget.HeightPosition", null);
    this.wdHoistTypeSelection = config.get("widget.HoistTypeSelection", null);

    this.scalingFactor = getComputedStyle(document.body).getPropertyValue('--scaling');
    
    this.images = [
      "workspace1.00 [t].png",
      "workspace2.00 [t].png",
      "workspace3.00 [t].png",
      "workspace4.00 [t].png",
      "workspace5.00 [t].png",
      "workspace6.00 [t].png",
      "workspace7.00 [t].png",
      "workspace8.00 [t].png",
      "workspace9.00 [t].png",
      "workspace10.00 [t].png",
      "workspace11.00 [t].png",
      "workspace12.00 [t].png",
    ];

    this.tonsValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

    this.image = document.getElementById("image");
    this.triangle = document.getElementById("triangle");
    this.lineHor = document.getElementById("lineHor");
    this.lineVer = document.getElementById("lineVer");
    this.container = document.getElementById("container");
    this.tonText = document.getElementById("tonText");
    
    // ensuring max and min values coincide with png labels
    this.maxHorCor = 435 * this.scalingFactor;
    this.maxVerCor = 324 * this.scalingFactor;
    this.minHorCor = 0 * this.scalingFactor;
    this.minVerCor = 324 * this.scalingFactor;
    // axes for adding labels
    this.lineAsHor = document.getElementById("lineAsHor");
    this.lineAsVer = document.getElementById("lineAsVer");
    
    this.basePosLineHor = 220;
    this.basePosLineVer = 200;
    
    this.valLineHor = 25;
    this.valLineVer = -5;

    this.image.onload = () => {
      this.updateCross();
    };

    this.img = document.getElementById("image");
    this.img.src = "./Reel_pngs/" + this.images[0];

    this.AddNumbersHor();
    this.AddNumbersVer();

  }

  updateCross() {
    let hor = this.minHorCor + (this.valLineHor / 30) * this.maxHorCor;
    let ver = this.minVerCor*(1 - this.valLineVer /25);
    this.lineHor.style.top = `${ver}px`;
    this.lineVer.style.left = `${hor}px`;
  }

  AddNumbersHor() {
    let firstPos = 0;
    let firstNumber = 0;

    for (let i = 0; i < 7; i++) {
      let varName = `number${i}n${firstNumber}`;
      const node = document.createElement(varName);
      node.style.position = "absolute";
      node.style.top = `${455 * this.scalingFactor}px`; // scale
      node.style.width = `${1 * this.scalingFactor}px`;
      node.style.height = `${15 * this.scalingFactor}px`;
      node.style.left = `${firstPos}px`;
      node.style.fontSize = `${22 * this.scalingFactor}px`;
      node.style.fontWeight = "600";
      node.style.color = "lime";
      node.textContent = firstNumber;
      this.lineAsHor.appendChild(node);
      
      firstPos += 71.5 * this.scalingFactor; // scale
      firstNumber += 5;
    }
  }

  AddNumbersVer() {
    let firstPos = -3 * this.scalingFactor; // scale
    let firstNumber = -10;
    
    for (let i = 0; i < 8; i++) {
      let varName = `number${i}n${firstNumber}`;
      const node = document.createElement(varName);
      node.style.position = "absolute";
      node.style.bottom = `${firstPos}px`;
      // node.style.width = `${1}px`;
      node.style.height = `${15 * this.scalingFactor}px`;
      node.style.left = `${-30 * this.scalingFactor}px`;
      node.style.fontSize = `${22 * this.scalingFactor}px`;
      node.style.fontWeight = "600";
      node.style.color = "lime";
      node.textContent = firstNumber;
      node.style.textAlign = "right";
      this.lineAsVer.appendChild(node);
      
      firstPos += 63.5 * this.scalingFactor; // scale
      firstNumber += 5;
    }
  }

  update(value, data) {
    this.valLineHor =  this.selectValue(data, this.wdHeightPosition);

    this.valLineVer = this.selectValue(data, this.wdRaduisPosition);

    this.valImageIndex = this.selectValue(data, this.wdHoistTypeSelection);

    if (this.valImageIndex < this.images.length) {
      this.img.src = "./Reel_pngs/" + this.images[this.valImageIndex];
    }

    this.tonText.textContent = this.tonsValues[this.valImageIndex] + " t";

    this.updateCross();
  }

  render() {
    // Render function logic
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
