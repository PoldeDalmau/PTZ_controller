class TimeDelta {
    constructor(nanos){
        this.nanos = nanos;
    }

    get seconds() {
        return this.nanos / 10e9;
    }

    get milliseconds(){
        return this.nanos / 10e6;
    }

    get microseconds() {
        return this.nanos / 10e3
    }

    get nanoseconds() {
        return this.nanos;
    }

    addToDate(date){
        return new Date(date.getTime() + this.milliseconds);
    }

    subtractFromDate(date){
        return new Date(date.getTime() - this.milliseconds);
    }

    static fromMilliseconds(milliseconds){
        return new TimeDelta(milliseconds * 10e6);
    }
    IntTypeConverter
    static fromNanoseconds(nanoseconds){
        return new TimeDelta(nanoseconds);
    }
}

class TypeConverter {
    static getBytes(target, data){
        return new Uint8Array(data.buffer.slice(
            data.byteOffset + target.addr[0],
            data.byteOffset + target.addr[0] + Math.ceil(target.size/8)
        ));
    }
}

class ComplexTypeConverter extends TypeConverter {
    static extract(target, data){
        if(!target.hasOwnProperty('children') || target.children.length === 0){
            console.error("Cannot extract a Complex Type with no children", target);
            return undefined;
        }
        const output = {};

        Object.keys(target.children).forEach(childKey => {
            const child = target.children[childKey];
            output[child['name']] = DataBlockTypes[child['type_id']].extract(child, data);
        });

        return output;
    }
}

class BoolTypeConverter extends TypeConverter {
    static extract(target, data){
        const bytes = this.getBytes(target, data);
        const mask = (1 << target.addr[1]);
        return bytes[0] & mask > 0;
    }
}

// class ByteTypeConverter extends TypeConverter {
//     extract(target, data){
//         return this.getBytes(target, data);
//     }
// }
//
// class WordTypeConverter extends ByteTypeConverter {}
//
// class DWordTypeConverter extends ByteTypeConverter {}
//
// class LWordTypeConverter extends ByteTypeConverter {}

class SIntTypeConverter extends TypeConverter {
    static viewGetter = DataView.prototype.getInt8;

    static extract(target, data){
        const bytes = super.getBytes(target, data);
        const view = new DataView(bytes.buffer);
        return this.viewGetter.apply(view, [0]);
    }
}

class IntTypeConverter extends SIntTypeConverter {
    static viewGetter = DataView.prototype.getInt16;
}

class DIntTypeConverter extends SIntTypeConverter {
    static viewGetter = DataView.prototype.getInt32;
}

class LIntTypeConverter extends SIntTypeConverter {
    static viewGetter = DataView.prototype.getBigInt64;
}

class USIntTypeConverter extends SIntTypeConverter {
    static viewGetter = DataView.prototype.getUint8;
}

class UIntTypeConverter extends USIntTypeConverter {
    static viewGetter = DataView.prototype.getUint16;
}

class UDIntTypeConverter extends USIntTypeConverter {
    static viewGetter = DataView.prototype.getUint32;
}

class ULIntTypeConverter extends USIntTypeConverter {
    static viewGetter = DataView.prototype.getBigUint64;
}

class RealTypeConverter extends SIntTypeConverter {
    static viewGetter = DataView.prototype.getFloat32;
}

class LRealTypeConverter extends RealTypeConverter {
    static viewGetter = DataView.prototype.getFloat64;
}

class TimeTypeConverter extends DIntTypeConverter {
    static extract(target, data){
        const milliseconds = super.extract(target, data);
        return TimeDelta.fromMilliseconds(milliseconds);
    }
}

class LTimeTypeConverter extends LIntTypeConverter {
    static extract(target, data){
        const nanoseconds = super.extract(target, data);
        return TimeDelta.fromNanoseconds(nanoseconds);
    }
}

class DTLTypeConverter extends TypeConverter {
    static extract(target, data) {
        const bytes = this.getBytes(target, data);

        const yearTarget = { addr: [0, 0], size: 16 };
        const year = UIntTypeConverter.extract(yearTarget, bytes);

        const monthTarget = { addr: [2, 0], size: 8 }
        const month = USIntTypeConverter.extract(monthTarget, bytes);

        const dayTarget = { addr: [3, 0], size: 8 };
        const day = USIntTypeConverter.extract(dayTarget, bytes);

        const weekdayTarget = { addr: [4, 0], size: 8 };
        const weekday = USIntTypeConverter.extract(weekdayTarget, bytes);

        const hourTarget = { addr: [5, 0], size: 8 };
        const hour = USIntTypeConverter.extract(hourTarget, bytes);

        const minuteTarget = { addr: [6, 0], size: 8 };
        const minute = USIntTypeConverter.extract(minuteTarget, bytes);

        const secondTarget = { addr: [7, 0], size: 8 };
        const second = USIntTypeConverter.extract(secondTarget, bytes);

        const nanosecondTarget = { addr: [8, 0], size: 32 };
        const nanosecond = UDIntTypeConverter.extract(nanosecondTarget, bytes);

        return new Date(
            year,
            month-1,  // Date constructor accepts a zero-indexed "monthIndex"
            day,
            hour,
            minute,
            second,
            nanosecond / 10e6  // JavaScript Data object only has millisecond precision
        );
    }
}

class CharTypeConverter extends TypeConverter {
    static extract(target, data){
        const bytes = this.getBytes(target, data);
        const converted = String.fromCharCode(bytes[0]);
        return converted[0];
    }
}

const DataBlockTypes = {
    '-3': ComplexTypeConverter,
    '-2': ComplexTypeConverter,
    '-1': ComplexTypeConverter,
    0: BoolTypeConverter,
    1: USIntTypeConverter,
    2: UIntTypeConverter,
    3: UDIntTypeConverter,
    4: ULIntTypeConverter,
    5: SIntTypeConverter,
    6: IntTypeConverter,
    7: DIntTypeConverter,
    8: LIntTypeConverter,
    9: USIntTypeConverter,
    10: UIntTypeConverter,
    11: UDIntTypeConverter,
    12: ULIntTypeConverter,
    13: RealTypeConverter,
    14: LRealTypeConverter,
    15: TimeTypeConverter,
    16: LTimeTypeConverter,
    17: DTLTypeConverter,
    18: CharTypeConverter
}

class DataBlock {
    constructor(definition, data) {
        this.definition = definition;
        this.data = data;
    }

    get(path) {
        const parts = path.split('.');
        parts.reverse();

        let target = this.definition;

        while(parts.length){
            const key = parts.pop();
            if(!target.hasOwnProperty('children')){
                console.error("Cannot get child", key, "from target with no children", target);
                return;
            }
            if(!target.children.hasOwnProperty(key)){
                console.error("Target", target, "has no child", key);
                return;
            }
            target = target.children[key];


        }

        if(!DataBlockTypes.hasOwnProperty(target.type_id)){
            console.error(target, "Does not have a known type");
        }
        return DataBlockTypes[target.type_id].extract(target, this.data);
    }

	// get all the paths from the tree, make them into a list
	// if a node has children it will not be alone. "add path at leaf only"
	static get_paths(paths_list, parent_path, element) {
		if (!Array.isArray(paths_list)) {
			console.error("paths_list must be an array");
			return;
		}
		if (element === undefined) {
			return;
		}
		if (element.children === undefined) {
			paths_list.push(parent_path);
		} else {
			for (let key in element.children) {
				let newParentPath = parent_path.length > 0 ? parent_path + "." : "";
				this.get_paths(paths_list, newParentPath + key, element.children[key]);
			}
		}
	}

	dump_all() {
		var output = '';
		var paths = [];
		DataBlock.get_paths(paths, '', this.definition);
		for (var i = 0; i < paths.length; ++i) {
			var path = paths[i];
			try {
				output += path + ' ' + this.get(path) + "\r\n";
			} catch (error) {
				output += path + ' ERROR ' + error;
				break;
			}
		}
		return output;
	}
}


function parseDefinition(definitions){
    let retries = [];
    let lastRetriesLength = 0;

    const outputTree = {children: {}};

    const processDef = (output, retryArray, def) => {
        const parts = def['path'].split('.');
        const rParts = [...parts].reverse();
        let parent = output;

        if(parts.length > 1){
            while(rParts.length > 1){
                const part = rParts.pop();
                if(!parent.hasOwnProperty('children')){
                    console.error("Tried to add", def, "to", parent, "but it is not expecting children");
                    return;
                }
                if(!parent.children.hasOwnProperty(part)){
                    retryArray.push(def);
                    return;
                }
                parent = parent.children[part];
            }
        }

        let descriptor;

        if(def['type'].toLowerCase() === 'data block' ||
            def['type'].toLowerCase() === 'user defined type' ||
            def['type'].toLowerCase() === 'struct'){
            descriptor = {...def, children: {}};
        }else {
            descriptor = def;
        }

        if(parent.hasOwnProperty('children')){
            parent.children[def['name']] = descriptor;
        }else {
            parent[def['name']] = descriptor;
        }
    };

    definitions.forEach(def => {
        processDef(outputTree, retries, def);
    });

    while(retries.length !== lastRetriesLength){
        lastRetriesLength = retries.length;

        const oldRetries = retries;
        retries = [];

        oldRetries.forEach(def => {
            processDef(outputTree, retries, def);
        });
    }

    if(retries.length > 0){
        console.error("Some definitions could not be processed into the tree")
        retries.forEach(def => console.error(def));
    }

    return outputTree;
}


let dataBlockDefinition = null;

function dataBlockError(){
    setTimeout(requestDataBlock, 1000);
}

function requestDataBlock() {
    const queryParams = new URLSearchParams(window.location.search);
    let data = queryParams.get('widget.descriptors');

    if(data === null || data === '<-{url_datablock_descriptors}->'){
        console.warn("No PLC Data Block Descriptors in URL Query Params. Fetching from HTTP");
        const req = new XMLHttpRequest();
        req.open("GET", "/widgets/plc_data_block.json");
        req.onerror = dataBlockError;
        req.onload = _ => {
			if (req.status != 200) {
				console.warn("Response from server was " + req.status + " expected 200");
				return;
			}
            dataBlockDefinition = parseDefinition(JSON.parse(req.response)['descriptor_set']);
        };
        req.send();
        return;
    }

    const json = decodeURI(data);
    dataBlockDefinition = parseDefinition(JSON.parse(json)['descriptor_set']);
}

setTimeout(requestDataBlock, 0);
