class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdPositionLuffing = config.get("widget.PositionLuffing", null);
    this.wdLowerLimitLuffing = config.get("widget.LowerLimitLuffing", null);
    this.wdUpperLimmitLuffing = config.get("widget.UpperLimitLuffing", null);

    this.wdPositionFolding = config.get("widget.PositionFolding", null);
    this.wdLowerLimitFolding = config.get("widget.LowerLimitFolding", null);
    this.wdUpperLimmitFolding = config.get("widget.UpperLimitFolding", null);

    // get HTML elements
    this.borderLuffing = document.getElementById("borderRingLuffing");
    this.borderFolding = document.getElementById("borderRingFolding");

    this.numbersLuffingContainer = document.getElementById("numbersLuffing");
    this.numbersFoldingContainer = document.getElementById("numbersFolding");

    this.ticksContainerLuffing = document.getElementById("ringForTicksLuffing");
    this.ticksContainerFolding = document.getElementById("ringForTicksFolding");

    this.pieLuffing = document.getElementById("pieLuffing");
    this.pieFolding = document.getElementById("pieFolding");

    this.needleWhiteLeftLuffing = document.getElementById(
      "needleWhiteLeftLuffing"
    );
    this.needleBlackLuffing = document.getElementById("needleBlackLuffing");
    this.needleWhiteRightLuffing = document.getElementById(
      "needleWhiteRightLuffing"
    );

    this.needleWhiteLeftFolding = document.getElementById(
      "needleWhiteLeftFolding"
    );
    this.needleBlackFolding = document.getElementById("needleBlackFolding");
    this.needleWhiteRightFolding = document.getElementById(
      "needleWhiteRightFolding"
    );

    this.speedLuffing = document.getElementById("speedLuffing");
    this.speedFolding = document.getElementById("speedFolding");

    // containers -> bundling elements
    this.containerNumbers = [
      this.numbersLuffingContainer,
      this.numbersFoldingContainer,
    ];

    this.conatainerTicks = [
      this.ticksContainerLuffing,
      this.ticksContainerFolding,
    ];

    this.conatainerPie = [this.pieLuffing, this.pieFolding];

    this.containerLuffing = [
      this.needleWhiteLeftLuffing,
      this.needleBlackLuffing,
      this.needleWhiteRightLuffing,
    ];

    this.containerFolding = [
      this.needleWhiteLeftFolding,
      this.needleBlackFolding,
      this.needleWhiteRightFolding,
    ];

    // values and postions
    this.ticksPosition = [-100, -75, -50, -25, 0, 25, 50, 75, 100];
    this.numbers = [100, 75, 50, 25, 0, -25, -50, -75, -100];

    this.AddPieColors();
    this.AddNumbers();
    this.AddTicks();

    // set needles positions
    this.SetNeedle(this.containerLuffing, 0, -25);
    this.SetNeedle(this.containerLuffing, 1, 0);
    this.SetNeedle(this.containerLuffing, 2, 25);

    this.SetNeedle(this.containerFolding, 0, -25);
    this.SetNeedle(this.containerFolding, 1, 0);
    this.SetNeedle(this.containerFolding, 2, 25);

    this.speedLuffing.innerText = `Speed (${0})`;
    this.speedFolding.innerText = `Speed (${0})`;
  }

  AddNumbers() {
    this.containerNumbers.forEach((elemContainer, indexContainer) => {
      this.numbers.forEach((num) => {
        const numberElem = document.createElement("div");
        numberElem.className = "number";
        numberElem.textContent = -num;

        const angle = ((num + 100) * 180) / 200;
        const radians = (angle * Math.PI) / 180;

        const x = 50 + 45 * Math.cos(radians); // 50 is the center, 45 is radius
        const y = 50 - 45 * Math.sin(radians); // 50 is the center, 45 is radius

        numberElem.style.left = `${x}%`;
        numberElem.style.top = `${y}%`;

        this.containerNumbers[indexContainer].appendChild(numberElem);
      });
    });
  }

  AddTicks() {
    this.conatainerTicks.forEach((num, indexContainer) => {
      this.ticksPosition.forEach((num, index) => {
        if (index >= 3 && index <= 5) {
          return;
        }

        const numberElem = document.createElement("div");
        numberElem.className = "number";

        const angle = ((num + 100) * 180) / 200;
        const radians = (angle * Math.PI) / 180;

        const x = 50 + 45 * Math.cos(radians);
        const y = 50 - 45 * Math.sin(radians);

        numberElem.style.left = `${x}%`;
        numberElem.style.top = `${y}%`;
        numberElem.style.width = `1px`;
        numberElem.style.height = `22px`;
        numberElem.style.backgroundColor = `black`;
        numberElem.style.transform = `rotate(${-angle + 90}deg)`;

        this.conatainerTicks[indexContainer].appendChild(numberElem);
      });
    });
  }

  AddPieColors() {
    this.conatainerPie.forEach((num, index) => {
      let firstValue = 45;
      let secondValue = 65;
      let thirdValue = 295;
      let fourthValue = 315;

      this.conatainerPie[
        index
      ].style.backgroundImage = `conic-gradient(white 0deg ${firstValue}deg, #d8d8d8 ${firstValue}deg ${secondValue}deg, #bfbfbf ${secondValue}deg ${thirdValue}deg, #d8d8d8 ${thirdValue}deg ${fourthValue}deg, white ${fourthValue}deg 360deg, white 360deg 360deg)`;
    });
  }

  SetNeedle(containerNeedles, index, value) {
    const maxValue = 100;
    const minValue = -100;
    const angle = ((value - minValue) * 180) / (maxValue - minValue);
    containerNeedles[index].style.transform = `rotate(${angle - 90}deg)`;
  }

  update(value, data) {
    this.dataNeedleBlackLuffing = this.selectValue(
      data,
      this.wdPositionLuffing
    );
    this.dataNeedleWhiteLeftLuffing = this.selectValue(
      data,
      this.wdLowerLimitLuffing
    );
    this.dataNeedleWhiteRightLuffing = this.selectValue(
      data,
      this.wdUpperLimmitLuffing
    );

    this.dataNeedleBlackFolding = this.selectValue(
      data,
      this.wdPositionFolding
    );
    this.dataNeedleWhiteLeftFolding = this.selectValue(
      data,
      this.wdLowerLimitFolding
    );
    this.dataNeedleWhiteRightFolding = this.selectValue(
      data,
      this.wdUpperLimmitFolding
    );

    this.SetNeedle(this.containerLuffing, 0, this.dataNeedleWhiteLeftLuffing);
    this.SetNeedle(this.containerLuffing, 1, this.dataNeedleBlackLuffing);
    this.SetNeedle(this.containerLuffing, 2, this.dataNeedleWhiteRightLuffing);

    this.SetNeedle(this.containerFolding, 0, this.dataNeedleBlackFolding);
    this.SetNeedle(this.containerFolding, 1, this.dataNeedleWhiteLeftFolding);
    this.SetNeedle(this.containerFolding, 2, this.dataNeedleWhiteRightFolding);

    this.speedLuffing.innerText = `Speed (${this.dataNeedleBlackLuffing})`;
    this.speedFolding.innerText = `Speed (${this.dataNeedleBlackFolding})`;
  }

  render() {}
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
