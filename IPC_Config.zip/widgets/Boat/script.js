class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        // get PLC data
        this.wdSlewingAngle = config.get('widget.SlewingAngle', null);
        
        // hardcoded value for demo purposes:
        this.angleSlewing = 50;
        this.angsleSlewingUpdate = true;

        setInterval(() => {
                if (this.angsleSlewingUpdate) {
                    this.angleSlewing++;
                    if (this.angleSlewing >= 75) {
                        this.angsleSlewingUpdate = false;
                    }
                } else {
                    this.angleSlewing--;
                    if (this.angleSlewing <= -50) {
                        this.angsleSlewingUpdate = true;
                    }
                }
            this.Draw();
    
        }, 100);

        this.Draw()
    }

    updateElement(nameOfElement, leftCoor, topCoor, angleDegr) {
        const element = document.getElementById(nameOfElement);
        const newLeft = leftCoor + "px";
        const newTop = topCoor + "px";
        const rotation = "rotate(" + angleDegr + "deg)";
    
        element.style.left = newLeft;
        element.style.top = newTop;
        element.style.transform = rotation;
    }

    Draw(){
        const topYCoor = 90;
        const leftXCoor = 43;

        this.updateElement("baseCrane", leftXCoor, topYCoor, 0);
        this.updateElement("armCrane", leftXCoor + 20, topYCoor, this.angleSlewing);
    }

    update(value, data)
    {
        this.posSlewing = this.selectValue(data, this.wdSlewingAngle);
    }

    render(){
    }

    demo(demoValue) 
    {
        if (this.increasing) 
        {
            demoValue++;
            this.demovalue = demoValue;
            this.displaySymbol(demoValue);
            if (demoValue >= 90) 
            {
                this.increasing = false;
            }
        } 
        else 
        {
            demoValue--;
            this.demovalue = demoValue;
            this.displaySymbol(demoValue);
            if (demoValue <= 0) 
            {
                this.increasing = true;
            }
        }
    }

    setupInterval()
    {
        setInterval(() => {this.demo(this.demovalue);},100);
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);