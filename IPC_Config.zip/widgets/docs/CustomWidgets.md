# Custom Widgets

This document contains information that is useful in the development of custom HTML5 Widgets.

## Widget API(s)

As the Widgets are standard HTML5 pages running in a web browser they have access to the standard DOM/JavaScript APIs found in any modern web browser.
In addition to this, a light framework has been created with some additional functionality that is useful for creating widgets.

#### `meta.json`

The `meta.json` file for each Widget defines metadata that is used for the UI and when passing data into the Widget.

The file contains a `name` property, defining the human-friendly name of the Widget that is used in the UI, and the
`options` property which is a JSON Object of the Config Options for the Widget, discussed further in the "Widget Options"
section of this document.

#### Connection Error Indicator

The framework has a builtin error alert. This is used to indicate that there is a connection problem from the Widget
to the `data_server`. This can be easily seen if the `data_server` is stopped, or (in the WatchMaster UI only), if the
Browser is disconnected from the Server running the `data_server` software.

To include this Indicator in your own Widgets:
* Create a `div` with an `id` of `alert-sign` in your Widget HTML, after the main content.
* Include `base.css`
* Include `base.js`

#### Robust Data Connection

The framework provides a built-in mechanism for maintaining a robust data connection to the `data_server`.
This will:
* Connect to the `data_server`
* Abort the connection attempt if no connection is established within 3 seconds and go into the error state
* Go into the error state if the connection is closed or there is another connection error
* Update the Connection Error Indicator when moving into, or out of, the error state
* Attempt to make a new connection 3 seconds after moving to the error state

The result of which is, a 3 second connection timeout with connection retries every 3 seconds.

#### Resizing

Loading the HTML Page into the browser triggers an initial Resize Event. Resizing the Browser Window will trigger further
Resize Events. 

The framework handles the capture and dispatch of Window Resize events, these are most important for the UI preview
as the Compositor Browser Windows must be recreated when their size changes.

The framework throttles Resize Events, and they are dispatched at most 4 times per second.

The framework will take care of resizing the Canvas and updating the aspect ratio of the 3D Camera, the updated context,
along with the new width & height will be passed into a call to the Widget's `resize` method.

#### Widget Options

The framework provides functionality for loading in Widget configuration options from URL Query Strings.

These will be merged with any default values that are hard-coded in to the Widgets.

Values can be accessed in Widget code using:
```
config.get('widget.pitchSelector', null);
```
Here `null` is a default value in case the requested path is not present in the config.

This value could be set by including `?widget.pitchSelector=x.y.z` in the Widget URL, and the above call would then 
return the string `x.y.z`.

Option values are generally strings, so numbers etc. will need to be parsed.

##### Option Definition
The available options for a Widget can be defined in the `meta.json` file. These options will be available in the UI
once the UI `config.json` has been updated, instructions for this can be found in the UI `Install.md`.

An option definition is a JSON Object that looks like this, with the `"options"` key of the `meta.json`:
```
"max": {
  "name": "Max Value",
  "type": "number",
  "default": 100
}
```

Here:
* The `id` of the Option is `"max"`, it will be sent to the Widget as `widget.max`
* The `name` of the Option that is shown in the UI will be "Max Value"
* The `type` of this Option is a `"number"`, this determines what control is used in the UI, 
more information on types can be found below
* The `default` value of `100` provides an initial value in case the User does not specify a value

##### Option Types
Several options types are available within the UI. Most of them are available to the Widget as a string.

`number`
* `id` The name that will Identify the options when it is passed into the Widget.
* `name` The human-friendly name that will Identify the option within the UI.
* `min` The minimum allowed value. The UI will not allow a value smaller than this.
* `max` The maximum allowed value. The UI will not allow a value bigger than this.
* `default` The default value that the option will have at the start.

`string`
* `id` The name that will Identify the options when it is passed into the Widget.
* `name` The human-friendly name that will Identify the option within the UI.
* `default` The default value that the option will have at the start.

`enum`
* `id` The name that will Identify the options when it is passed into the Widget.
* `name` The human-friendly name that will Identify the option within the UI.
* `values` An array of objects with the following properties:
    * `id` The string that will be used for the enum value when it is passed into the Widget.
    * `name` The human-friendly name that will Identify possible enum values in the UI.
* `default` The default value that the option will have at the start.

`rgba`
* `id` The name that will Identify the options when it is passed into the Widget.
* `name` The human-friendly name that will Identify the option within the UI.
* `default` The default value that the option will have at the start.

`array`
* `id` The name that will Identify the options when it is passed into the Widget.
* `name` The human-friendly name that will Identify the option within the UI.
* `elementName` The human-friendly name for an element of the Array to use in the UI e.g. "Row" will be used to label
buttons as "Add new Row" or "Delete Row".
* `elementOptions` A JSON Object with the same structure as the root `options`, defining the options for each element
within the array.
* `minLength` The minimum number of elements that are allowed in the array.
* `maxLength` The maximum number of elements that are allowed in the array.

#### Widget Types

There are currently 4 types of Widget available:
1. `stardust`

A WebGL Based 2D Widget.

1. `canvas2d`

A HTML5 2D Canvas Widget.

1. `three.js`

A WebGL Based 3D Widget using a camera with Perspective Projection.

1. `three.js.orthographic`

Identical to the standard `three.js` Widget Type, but with uses a camera with an Orthographic Projection
(parallel projection).

## Recommendations

The HTML Body Element is transparent by default, so no Styling is necessary.

#### Size & Positioning

The Compositor Browser must send all the pixels of a Widget to the Compositor. For maximum performance, design the widget
so that it can be as small as possible & has a minimum of empty space.

For example:
* If the widget has a background, make it fill the entire Browser Window, so it is clear how much work the 
Compositor Browser will be doing.
* Make any margins as small as possible.
* Make your design scale with the size of the Browser Window.
* If using a 3D Model, position the Model or Camera so that the viewport will be filled.

#### Render Workload

Every pixel of every frame must be transferred to from the Compositor Browser to the Compositor, but optimisations can
be made in the Browser render process:
* If the Widget has a static background, use a separate Canvas element positioned behind the main canvas.
Render once to this Canvas each time the Widget is resized, this means the main canvas will only need to be composited
over the background for each frame.
* If the data for a Widget will not change every frame (60fps) check if the data value has changed before re-rendering.
* If only a small area of the Widget will change with the data, use a smaller main canvas and position it to reduce
the amount of pixels that must be rendered when the data changes.
