# Installation

Widgets must be made available to the Compositor & WatchMaster UI over HTTP.
This can be done by serving the Widget directory using a standard HTTP Server.

The Widgets must be available to both the Server running the Compositor software and the PC running the Web UI.

The UI can be configured to use different Base URLs for the Compositor & the UI so that e.g. the Compositor can access
them via `localhost`, while the UI can access them via a LAN IP.

# Custom Widgets

To Install a Custom Widget, copy the directory to the Widget Directory so that it is served over HTTP. This will allow
the Widget to be access by the compositor.

To use the Widget in the UI, it must be added there separately. Information on this procedure is contained in the
WatchMaster UI Installation documentation.
