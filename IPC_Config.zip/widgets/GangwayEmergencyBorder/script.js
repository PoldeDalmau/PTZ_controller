class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdEmergencyActive = config.get("widget.EmergencyActive", null);

    // get HTML elements
    this.borderDiv = document.getElementById("borderDiv");

    this.dummy = 0;

    this.borderDiv.style.backgroundColor = `transparant`;
    this.borderDiv.style.height = `100%`;
    this.borderDiv.style.width = `100%`;

    this.showEmergency = false;
  }

  update(value, data) {
    this.showEmergency = this.selectValue(data, this.wdEmergencyActive);
  }

  render() {
    this.dummy++;
    if (this.dummy > 2) {
      this.dummy = 0;
    }

    this.borderDiv.style.height = `${1 + this.dummy / 200}%`;
    this.borderDiv.style.width = `${1 + this.dummy / 200}%`;

    this.borderDiv.style.backgroundColor = `rgb(255,255,0, ${
        0.98 + this.dummy / 200
      })`;

    if (this.showEmergency == 1) {
      this.borderDiv.style.backgroundColor = `rgb(255,255,0, ${
        0.98 + this.dummy / 200
      })`;
      this.borderDiv.style.height = `100%`;
      this.borderDiv.style.width = `100%`;
    }
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
