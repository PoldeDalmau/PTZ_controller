class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        this.dataValuePath = config.get('widget.Data', null);
        // this.speedsetpoint;// = 50;
        this.progressBar = document.getElementById('progressBar');
        this.progressValue = document.getElementById('progressValue');
        // this.updateProgressBar(this.speedsetpoint)
    }

    updateProgressBar(percent) {
        // Get the progress bar element
        // const progressBar = document.getElementById('progressBar');
        // const progressValue = document.getElementById('progressValue');
        // Function to update the width of the progress bar
        // Ensure percent is within valid range (0 to 100)
        percent = Math.max(0, Math.min(100, percent));
        percent = percent.toFixed(1);
        crossOriginIsolated.log(percent);
        // Set the width of the progress bar based on the percent value
        progressBar.style.width = percent + '%';
        progressValue.innerText = percent + '%'; // Update the text content of progressValue element
    
        // Battery status
        const lowmid = 30;
        const midhigh = 60;
    
        if (percent < lowmid){
            progressBar.style.backgroundColor = 'red';
        } else if (percent > midhigh){
            progressBar.style.backgroundColor = 'green';
        } else {
            progressBar.style.backgroundColor = 'orange';
        }
    }
    update(value,   data)
    {
        let speedsetpoint = this.selectValue(data, this.dataValuePath);
        console.log(speedsetpoint);
        this.updateProgressBar(speedsetpoint);
    }
    render(){
        // this.speedsetpoint = 30;
        // updateProgressBar(this.speedsetpoint);
    }

}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);

// const max = 100;
// let currentValue = 0;
// let increasing = true;

// // Battery status
// const lowmid = 30;
//const midhigh = 60;
//
//// Example: Update the progress bar width to 75%
//function demo() 
//{
//    if (increasing) 
//    {
//        currentValue++;
//        updateProgressBar(currentValue); 
//        if (currentValue >= max) 
//        {
//            increasing = false;
//        }
//    } else 
//    {
//        currentValue--;
//        updateProgressBar(currentValue);
//        if (currentValue <= 0) 
//        {
//            increasing = true;
//        }
//    }
//    
//    if (currentValue < lowmid){
//        progressBar.style.backgroundColor = 'red';
//    } else if (currentValue > midhigh){
//        progressBar.style.backgroundColor = 'green';
//    } else {
//        progressBar.style.backgroundColor = 'orange';
//    }
//    setTimeout(demo, 30);
//}
//
////demo();