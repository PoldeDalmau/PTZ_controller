class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        // get PLC data
        this.wdEmergencyActive = config.get('widget.EmergencyActive', null);
        
        // get HTML elements
        this.borderDiv = document.getElementById('borderDiv');
        this.textEmer = document.getElementById('textEmer');

        this.dummy = 0;

        this.showEmergency = true;

        this.renderText();
    }

    displaySymbol(nameOfElement, number) {
        nameOfElement.textContent = `${number}\u00B0`;        
    }

    update(value, data)
    {
        this.dummy++;
        if (this.dummy > 2) {
            this.dummy = 0;
        }

        this.showEmergency = this.selectValue(data, this.wdEmergencyActive);
    }

    renderText(){
        this.borderDiv.style.border = `1px solid rgb(0,0,0, ${0.98 + this.dummy/200})`;
        this.textEmer.innerText = "";
        this.textEmer.style.backgroundColor = `transparent`;

        if ((this.showEmergency) == 1){
            this.textEmer.innerText = "EDS imminent";
            this.textEmer.style.backgroundColor = `yellow`;
        }
    }

    render(){
        this.renderText();
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);