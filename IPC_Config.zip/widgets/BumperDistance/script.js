class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    this.wdNameOfSlider = config.get("widget.NameOfWidget", null);
    // get HTML elements
    this.progBar = document.getElementById("progressBar");
    this.container = document.getElementById("container");
    this.wrapper = document.getElementById("wrapper");
    this.textContainer = document.getElementById("textContainer");
    this.titleText = document.getElementById("titleid");
    // this.wdTitle.textContent = "Bumper distance";
    
    
    // get PLC data
    this.wdstepNum = config.get("widget.stepNumber", null);
    this.currentStep = 2;
    this.wdBumperDistance = config.get("widget.BumperDistance", null);
    // this.wdTitle.textContent = config.get("widget.title", null);
    
    this.colorsBar = ["#bebebe", "#d7d9d9", "white", "#d7d9d9", "#bebebe"];

    // Bar value in percentage
    this.barValue = 10;
    this.maxRangeBar = 287.5;

    this.maxVal = 100; // maximum bumper distance in cm

    this.dummy = 0;
    this.AddBar();
    this.Draw();
  }

  AddBar() {
    this.progBar.replaceChildren();
    this.textContainer.textContent = (this.barValue).toFixed(0) + " cm";// /" + this.maxVal + " cm";  
    let varName = `node`;
    const node = document.createElement(varName);
    node.style.position = "absolute";
    node.style.width = `100%`;
    node.style.height = `${(this.maxVal - this.barValue) * 100 / this.maxVal}%`;
    node.style.bottom = "0px";
    // node.style.height = `${this.maxRangeBar*(this.barValue/100)}px`;
    // node.style.left = `${0}px`;
    node.style.backgroundColor = `rgba(0,255,0,${0.98 + this.dummy /200})`;
    node.style.borderRadius = "1px";
    this.progBar.appendChild(node);
  }

  Draw() {
    this.AddBar();
    if(this.currentStep == 2){
      this.container.classList.remove('hidden');
      this.textContainer.style.color = 'lime';
      this.titleText.style.color = "lime";
      this.wrapper.style.backgroundColor = `rgba(0,0,0,${0.6 + this.dummy/200})`
    } else {
      this.titleText.style.color = "transparent";
      this.container.classList.add('hidden');
      this.wrapper.style.backgroundColor = `rgba(0,0,0,${this.dummy/200})`
      this.textContainer.style.color = 'transparent';
    }
  }
  
  update(value, data) {
    this.barValue = this.selectValue(data, this.wdBumperDistance);
    this.currentStep = this.selectValue(data,this.wdstepNum);

    this.dummy++;
    if(this.dummy > 2){
      this.dummy = 0;
    }
    this.Draw();
  }

  render() {}
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
