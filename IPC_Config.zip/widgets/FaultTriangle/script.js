class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        // get PLC data
        this.wdFaultTriangle = config.get('widget.FaultTriangleStatus', null);
        this.box = document.getElementById('box');
        this.blinkingImage = document.getElementById('imageFaultTriangle');
        
        this.dummy =0; // prevents widget from being idle for too long and making watchman go on "Pease stand by"
    }

    update(value, data)
    {

        let faultTriangleStatus = this.selectValue(data, this.wdFaultTriangle);
        this.dummy ++;
        let isFadedOut = false;
        if (this.dummy > 2){
            this.dummy = 0;
            isFadedOut = !isFadedOut;
        }
        if (faultTriangleStatus){
            if (isFadedOut) {
                this.blinkingImage.style.opacity = 0.98 + this.dummy/200;
            } else {
                this.blinkingImage.style.opacity = 0.5 + this.dummy/200;
            }
        }
        else {
            this.blinkingImage.style.opacity = this.dummy/300;
        }
    }

    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);