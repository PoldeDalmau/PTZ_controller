class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    this.wdNameOfSlider = config.get("widget.NameOfWidget", null);
    this.wdUnitOfSlider = config.get("widget.UnitOfWidget", null);

    // get PLC data
    this.wdPosition = config.get("widget.Position", null);
    this.wdLowSpeedMinusArea = config.get("widget.LowSpeedMinusArea", null);
    this.wdLimitMinus = config.get("widget.LimitMinus", null);
    this.wdLimitPlus = config.get("widget.LimitPlus", null);
    this.wdLowSpeedPlusArea = config.get("widget.LowSpeedPlusArea", null);
    this.wdStartPosition = config.get("widget.StartPosition", null);
    this.wdEndPosition = config.get("widget.EndPosition", null);

    // get HTML elements
    this.nameOfSlider = document.getElementById("nameOfSlider");
    this.container = document.getElementById("container");
    this.pointerBlock = document.getElementById("pointerBlock");
    this.containerBar = document.getElementById("containerPointer");
    this.progBar = document.getElementById("progressBarLuffing");
    this.namesContainers = ["containerPointer"];

    this.colorsBar = [`rgb(190, 190, 190. 0.4)`, `rgb(215, 217, 217, 0.4)`, "rgb(215, 217, 217, 0.6)", `rgb(215, 217, 217, 0.4)`, `rgb(190, 190, 190. 0.4)`];

    // width in pixels
    this.firstWidth = 31;
    this.secondWidth = 30;
    this.thirdWidth = 150;
    this.fourthWidth = 30;
    this.fifthWidth = 31;

    this.widthBarsLuffing = [
      this.firstWidth,
      this.secondWidth,
      this.thirdWidth,
      this.fourthWidth,
      this.fifthWidth,
    ];

    this.valueBar =40;
    this.startPosition = 0;
    this.endPosition = 40;
    this.diffStartEnd = this.endPosition - this.startPosition;
    this.posPointer;
    this.lengthOfLimits = 257.5;

    this.rangesCointainer = [this.rangesContLuffing];

    this.dummy = 0;

    this.progBar.replaceChildren();
    this.containerBar.replaceChildren();

    this.Draw();
    this.AddColorBlocks();
    this.AddNumbers();
    this.AddBars();
  }

  AddColorBlocks() {
    let firstPos = 0;
    for (let i = 0; i < 5; i++) {
      let varName = `node${i}TEST${i}`;
      const node = document.createElement(varName);
      node.style.position = "absolute";
      node.style.top = `${firstPos}px`;
      node.style.width = `100%`;
      node.style.height = `${this.widthBarsLuffing[i]}px`;
      node.style.left = `${0}px`;
      firstPos += this.widthBarsLuffing[i];
      node.style.backgroundColor = this.colorsBar[i];
      this.progBar.appendChild(node);
    }
  }

  AddBars() {
    let range = this.endPosition - this.startPosition;
    let firstPos = 10;

    for (let i = this.startPosition; i < this.endPosition + 1; i++) {
      let varName = `smallBars${i}`;
      const node = document.createElement(varName);
      node.style.position = "absolute";
      if (i % 10 == 0) {
        node.style.left = `${40}px`;
        node.style.height = `${1}px`;
        node.style.width = `${30}px`;
        node.style.top = `${firstPos}px`;
      } else if (i % 5 == 0) {
        node.style.left = `${45}px`;
        node.style.height = `${1}px`;
        node.style.width = `${25}px`;
        node.style.top = `${firstPos}px`;
      } else {
        node.style.left = `${50}px`;
        node.style.height = `${1}px`;
        node.style.width = `${15}px`;
        node.style.top = `${firstPos}px`;
      }

      node.style.backgroundColor = "lime";
      node.style.color = "lime";

      firstPos += 198 / range;

      this.containerBar.appendChild(node);
    }
  }

  AddNumbers() {
    let range = this.endPosition - this.startPosition;
    let interval;
    let marginLeft = 2;
    if (range > 50) {
      interval = 10;
      marginLeft = 2;
    } else if (range > 20) {
      interval = 5;
      marginLeft = 2;
    } else if (range > 10) {
      interval = 2;
      marginLeft = 2;
    } else {
      interval = 1;
      marginLeft = 5;
    }
    let firstPos;
    for (let j = 0; j < this.namesContainers.length; j++) {
      firstPos = 0;
      firstPos = 255;
      for (let i = this.startPosition; i < this.endPosition + 1; i++) {
        let varName = `number${i}n${this.namesContainers[j]}`;
        let offset = 57; // shifts numbers a bit to the top to ensure they stay inside the container
        const node = document.createElement(varName);
        if (i % interval == 0) {
          node.style.position = "absolute";
          node.style.left = `${5 + marginLeft}px`;
          node.style.width = `${20}px`;
          node.style.height = `${15}px`;
          node.style.top = `${firstPos - offset}px`;
          node.style.color = 'lime';
          node.style.fontSize = `${16}px`;
          node.style.textAlign = "left";
          node.textContent = Math.round(i);
        }

        firstPos -= 195 / range;

        this.containerBar.appendChild(node);
      }
    }
  }

  Draw() {
    this.posPointer = 32 + 
      (this.lengthOfLimits / this.diffStartEnd) *
      (this.endPosition  - this.valueBar) + 41.8;

    // convert from valueBar to px from top:
    this.pointerBlock.style.top = `${this.posPointer}px`;
    this.pointerBlock.textContent = Math.round(this.valueBar);
    this.nameOfSlider.textContent = this.wdNameOfSlider;

    this.container.style.backgroundColor = `rgb(0,0,0, ${
      0.5 + this.dummy / 200
    })`;
  }

  update(value, data) {
    this.containerBar.replaceChildren();
    this.progBar.replaceChildren();

    this.valueBar = this.selectValue(data, this.wdPosition);

    let vLowSpeedMinusArea = this.selectValue(data, this.wdLowSpeedMinusArea);
    let vLimitMinus = this.selectValue(data, this.wdLimitMinus);
    let vLimitPlus = this.selectValue(data, this.wdLimitPlus);
    let vLowSpeedPlusArea = this.selectValue(data, this.wdLowSpeedPlusArea);

    // start & end position
    this.startPosition = Math.floor(
      this.selectValue(data, this.wdStartPosition)
    );
    this.endPosition = Math.round(this.selectValue(data, this.wdEndPosition));
    this.diffStartEnd = Math.round(this.endPosition - this.startPosition);

    // calculate widdt of color blocks
    this.firstWidth =
      (this.lengthOfBar * (vLowSpeedMinusArea - this.startPosition)) /
      this.diffStartEnd;

    this.secondWidth =
      (this.lengthOfBar * (vLimitMinus - vLowSpeedMinusArea)) /
      this.diffStartEnd;

    this.thirdWidth =
      (this.lengthOfBar * (vLimitPlus - vLimitMinus)) / this.diffStartEnd;

    this.fourthWidth =
      (this.lengthOfBar * (vLowSpeedPlusArea - vLimitPlus)) / this.diffStartEnd;

    this.fifthWidth =
      (this.lengthOfBar * (this.endPosition - vLowSpeedPlusArea)) /
      this.diffStartEnd;

    this.dummy++;
    if (this.dummy > 2) {
      this.dummy = 0;
    }

    this.Draw();
    this.AddBars();
    this.AddColorBlocks();
    this.AddNumbers();
  }

  render() {}
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
