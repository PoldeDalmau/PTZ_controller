class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.textVal = config.get("widget.Text", null);

    this.wdLoad = config.get("widget.Load", null);
    this.wdOverload = config.get("widget.Overload", null);
    this.wdUnderload = config.get("widget.Underload", null);

    this.unitVal = config.get("widget.Unit", null);

    // css data
    this.scalingFactor = getComputedStyle(document.body).getPropertyValue(
      "--scaling"
    );
    
    // html
    this.TextContainer = document.getElementById("container");
    this.description = document.getElementById("description");
    this.valueAndUnit = document.getElementById("valueAndUnit");

    this.unit = this.unitVal;

    this.UpdateText(this.textVal);
    this.UpdateBorder(true);
  }

  UpdateBorder(underloadOrOverload) {
    if (underloadOrOverload) {
      this.TextContainer.style.color = "red";
      this.TextContainer.style.border = "5px solid red";
    } else {
      this.TextContainer.style.color = "lime";
      this.TextContainer.style.border = "5px solid rgb(0,0,0,0.0)";
    }
  }

  UpdateString(value, unit) {
    this.valueAndUnit.innerText = value + " " + unit;
  }

  UpdateText(name) {
    this.description.innerText = name;
  }

  update(value, data) {
    this.UpdateString(this.selectValue(data, this.wdLoad), this.unit);

    let overload = this.selectValue(data, this.wdOverload);
    let underload = this.selectValue(data, this.wdUnderload);

    let underloadOrOverload = false;
    if (overload == 1 || underload == 1) {
      underloadOrOverload = true;
    }

    this.UpdateBorder(underloadOrOverload);
  }

  render() {
    // Render function logic
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
