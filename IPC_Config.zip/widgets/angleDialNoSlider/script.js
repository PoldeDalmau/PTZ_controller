class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        //get plc data. 'widget.Data' is  
        // this.dataValuePath = config.get('widget.Data', null);
        
        // html objects that you want to manipulate
        this.container = document.getElementById('container');
        this.circle = document.getElementById('circle_container');
        this.angleArrow = document.getElementById("angleArrow");
        this.angleValue = document.getElementById("angleValue");
        this.circleRadius = this.circle.offsetWidth/2;
        
        // Set initial arrow position
        this.arrowPos = 45;
        this.arrowPosition(this.arrowPos);
        this.angleValue.textContent = `${90-this.arrowPos}\u00B0`;

        this.angles = [0,10,20,30,40,50,60,70,80,90];

        for (let i = 0; i < this.angles.length; i++) {
            let tick = document.createElement('div');
            tick.className = 'tick';

            // Append the tick to the container
            this.container.appendChild(tick);
            
            this.tickPosition(tick, this.angles[i], this.circleRadius);
        }
        
        // Set demo mode
        this.increasing = true;
        this.demo(this.arrowPos);
        this.setupInterval();
    }

    tickPosition(tick, angle, radius) 
    {
        let angleRad = angle*Math.PI/180;
        let scaleFactor = 0.975;
        let x = scaleFactor*radius*Math.cos(angleRad);
        let y = scaleFactor*radius*Math.sin(angleRad);
        tick.style.left = `${x}px`;
        tick.style.bottom = `${y}px`;
        tick.style.transform = `rotate(${-angle}deg)`;
    }

    arrowPosition(angle)
    {
        this.angleArrow.style.transform = `rotate(${angle}deg)`;
    }

    update(value, data)
    {
        // example of how to retrieve data from plc and pass it to the update function
        // let speedsetpoint = this.selectValue(data, this.dataValuePath);
        // this.updateProgressBar(speedsetpoint);
    }

    render(){
    }

    demo(demoValue) 
    {
        if (this.increasing) 
        {
            demoValue++;
            this.arrowPos = demoValue;
            this.arrowPosition(demoValue);
            this.angleValue.textContent = `${90-this.arrowPos}\u00B0`;
            if (demoValue >= 90) 
            {
                this.increasing = false;
            }
        } 
        else 
        {
            demoValue--;
            this.arrowPos = demoValue;
            this.arrowPosition(demoValue);
            this.angleValue.textContent = `${90-this.arrowPos}\u00B0`;
            if (demoValue <= 0) 
            {
                this.increasing = true;
            }
        }
    }

    setupInterval()
    {
        setInterval(() => {this.demo(this.arrowPos);},100);
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);