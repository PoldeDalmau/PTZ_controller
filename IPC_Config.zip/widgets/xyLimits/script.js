class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();
        this.vDataValuePath = config.get('widget.VerticalData', null);
        this.vMinValuePath = config.get('widget.Vertical min', null);
        this.vMaxValuePath = config.get('widget.Vertical max', null);

        this.hDataValuePath = config.get('widget.Horizontal data', null);
        this.hMinValuePath = config.get('widget.Horizontal min', null);
        this.hMaxValuePath = config.get('widget.Horizontal max', null);

        this.demoValuePath = config.get('widget.Demo', null);

        this.vertGaugeContainer = document.querySelector('.vertGaugeContainer');
        this.vertGauge = document.querySelector('.vertGauge');
        this.vertGaugeValue = document.querySelector('.vertGaugeValue');
        this.vertGaugeLabel = document.querySelector('.vertGaugeLabel');
        this.vertGaugeMark = document.querySelector('.vertGaugeMark');
        
        this.hmarks = [];
        this.vmarks = [];

        this.vDemo = 0;
        this.hDemo = 0;
        this.vIncreasing = true; 
        this.hIncreasing = true;
        this.drawGauge();

        this.primaryColors = ['#000000', '#059661', '#c2c2c2', '#004d00'];
        this.secondaryColors = ['#000000', '#0a885a', '#2695cc', '#005c3b'];
        this.pointerColors = ['#ffc500', '#ffc500', '#ff0000', '#7f6700'];
        this.colorValuePath = config.get('widget.Color', null);
    }

    drawGauge()
    {
        let maxValue = 100;
        let totalTicks = 50;

        for (let i = 0; i < totalTicks; i++) 
        {
            const mark = document.createElement('div');
            mark.classList.add('vertGaugeMark');
            mark.style.top = (i * 100) / (totalTicks) + '%';
            if (i % 5 === 0) 
            {
                mark.style.width = '40px'; 
            }
            this.vertGaugeContainer.appendChild(mark);
            this.vmarks.push(mark);
        }

        this.horGaugeContainer = document.querySelector('.horGaugeContainer');
        this.horGauge = document.querySelector('.horGauge');
        this.horGaugeValue = document.querySelector('.horGaugeValue');
        this.horGaugeLabel = document.querySelector('.horGaugeLabel');

        // Create gauge marks
        for (let i = 0; i < totalTicks; i++) 
        {
            const mark = document.createElement('div');
            mark.classList.add('horGaugeMark');
            mark.style.right = (i * 100) / (totalTicks) + '%';
            if (i % 5 === 0) 
            {
                mark.style.height = '40px'; 
            }
            this.horGaugeContainer.appendChild(mark);
            this.hmarks.push(mark);
        }
    }
    

    // Update gauge value and label
    updateGauge(vertValue, horValue, data)
    {
        let vMin = config.get('widget.Vertical min');//this.selectValue(data, this.vMinValuePath);
        let vMax = config.get('widget.Vertical max');//this.selectValue(data, this.vMaxValuePath);
        let vRange = vMax - vMin;

        const vertPercentage = ((vertValue - vMin) / vRange) * 100//(vertValue / vRange) * 100;
        this.vertGaugeValue.style.bottom = vertPercentage-2 + '%';
        this.vertGaugeLabel.textContent = vertValue;
        this.vertGaugeLabel.style.bottom = vertPercentage-5 + '%';
        this.vertGaugeValue.classList.add('vertPointer'); 

        let hMin = config.get('widget.Horizontal min');//this.selectValue(data, this.hMinValuePath);
        let hMax = config.get('widget.Horizontal max');//this.selectValue(data, this.hMaxValuePath);
        let hRange = hMax - hMin;

        const horPercentage = ((horValue - hMin)/ hRange) * 100;
        this.horGaugeValue.style.left = horPercentage-0.2 + '%';
        this.horGaugeLabel.textContent = horValue;
        this.horGaugeLabel.style.left = horPercentage-2 + '%';
        this.horGaugeValue.classList.add('horPointer');

    }

    update(value, data)
    {
        let demoVal = 0;//this.selectValue(data, this.demoValuePath);
        if(demoVal)
        {
            this.demo();
            this.updateGauge(this.vDemo, this.hDemo, data); // Update both vertical and horizontal gauges

        }else
        {
            let vertValue = Math.floor(this.selectValue(data, this.vDataValuePath));
            let horValue = Math.floor(this.selectValue(data, this.hDataValuePath));
            this.updateGauge(vertValue, horValue, data)
        }

        let index = this.selectValue(data, this.colorValuePath);
        let colorIndex = index % 4;

        this.vertGaugeValue.style.borderBottom = '14px solid ' +  this.pointerColors[colorIndex];
        this.horGaugeValue.style.borderBottom = '14px solid ' +  this.pointerColors[colorIndex];

        this.vertGaugeLabel.style.color = this.secondaryColors[colorIndex];
        this.horGaugeLabel.style.color = this.secondaryColors[colorIndex];

        //this.vertGaugeMark.style.backgroundColor = this.primaryColors[colorIndex]
        //let marks = this.vertGaugeContainer.querySelectorAll('.mark');
        for(let i = 0; i < this.hmarks.length; i++)
        {
            this.hmarks[i].style.backgroundColor = this.primaryColors[colorIndex];
            this.vmarks[i].style.backgroundColor = this.primaryColors[colorIndex];    
        }        
    }

    render()
    {
        //this.drawGauge();
    }

    

    demo() 
    {
        let vMin = config.get('widget.Vertical min');
        let vMax = config.get('widget.Vertical max');

        let hMin = config.get('widget.Horizontal min');
        let hMax = config.get('widget.Horizontal max');

        if (this.vIncreasing) 
        {
            this.vDemo++;
            if (this.vDemo >= vMax) 
            {
                this.vIncreasing = false;
            }
        } else 
        {
            this.vDemo--;
            if (this.vDemo <= vMin) 
            {
                this.vIncreasing = true;
            }
        }

        if (this.hIncreasing) 
        {
            this.hDemo++;
            if (this.hDemo >= hMax) 
            {
                this.hIncreasing = false;
            }
        } else 
        {
            this.hDemo--;
            if (this.hDemo <= hMin) 
            {
                this.hIncreasing = true;
            }
        }

        setInterval(this.demo, 200)
 
    }

}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
