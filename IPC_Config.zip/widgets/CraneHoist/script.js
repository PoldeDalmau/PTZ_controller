class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();

        this.wdNameOfWidget = config.get('widget.NameOfWidget', null);

        // get PLC data
        this.wdValue = config.get('widget.Value', null);
        
        // get HTML elements
        this.tableValues = document.getElementById('tableValues');
        this.container = document.getElementById('container');
        this.description = document.getElementById('description');
        this.progressValueLoad = document.getElementById('progressValueLoad');
        this.displaySymbol(this.progressValueLoad, 7000);

        this.displaySymbol(this.progressValueLoad, 0, false);

        this.description = this.wdNameOfWidget;
    }

    displaySymbol(nameOfElement, valueLoad) {
        nameOfElement.textContent = `${valueLoad}`;
    }

    update(value, data)
    {
        let valueNumber = this.selectValue(data, this.wdValue);

        this.displaySymbol(this.progressValueLoad, valueNumber);
    }
    render(){
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);