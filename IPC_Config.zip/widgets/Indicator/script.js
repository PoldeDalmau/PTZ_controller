class Component extends BaseComponent {
  constructor(context, width, height) {
    super();
    // dictionary for readability:

    this.df = {
      pushx: 0,
    };
    // this array contains the prefix to all html objects contained in the indicator.
    this.indicators = ["pushx_"];
    // contains names of the indicator
    this.indicatorTitles = ["NameOfIndicator"];

    // css values
    this.scalingFactor = getComputedStyle(document.body).getPropertyValue(
      "--scaling"
    );
    this.offsetfromHalf = getComputedStyle(document.body).getPropertyValue(
      "--offsetFromHalfCircle"
    );

    //config data
    this.wdNameOfIndicator = config.get("widget.NameOfIndicator", null);
    this.indicatorTitles = [this.wdNameOfIndicator];
    // this.indicatorTitles = ["dadbvggahsjg"];

    // this.wdIndexIndicator = config.get("widget.IndexOfIndicator", null);
    // this.indexOfIndicator = this.wdIndexIndicator;
    this.indexOfIndicator = 1;

    // get PLC data
    // this.wdStepNum = config.get("widget.StepNumber", null);
    this.currentStep = 6;

    this.wdPosition = config.get("widget.ArrowValue", null);
    // this.wdLowerLimit = config.get("widget.ArrowMinValue", null);
    // this.wdUpperLimit = config.get("widget.ArrowMaxValue", null);

    this.backgroundSegment1 = new Array(this.indicators.length);
    this.secondarySegment1 = new Array(this.indicators.length);
    this.terciarySegment1 = new Array(this.indicators.length);
    this.mainNeedle = new Array(this.indicators.length);
    this.circleDial = new Array(this.indicators.length);
    this.minNeedle = new Array(this.indicators.length);
    this.maxNeedle = new Array(this.indicators.length);
    this.numbersLuffingContainer = new Array(this.indicators.length);

    this.mainNeedleVal = new Array(this.indicators.length);
    this.minNeedleVal = new Array(this.indicators.length);
    this.maxNeedleVal = new Array(this.indicators.length);

    this.wrapperLeft = document.getElementById("wrapperLeft");
    this.htmlNameOffIndicator = document.getElementById("nameOffIndicator");

    // get HTML elements
    for (let ind = 0; ind < this.indicators.length; ind++) {
      this.backgroundSegment1[ind] = document.getElementById(
        `${this.indicators[ind]}c10`
      );
      this.numbersLuffingContainer[ind] = document.getElementById(
        `${this.indicators[ind]}numbers`
      );
      this.secondarySegment1[ind] = document.getElementById(
        `${this.indicators[ind]}c12`
      );
      this.terciarySegment1[ind] = document.getElementById(
        `${this.indicators[ind]}c13`
      );
      this.circleDial[ind] = document.getElementById(
        `${this.indicators[ind]}c_dial`
      );
      this.mainNeedle[ind] = document.getElementById(
        `${this.indicators[ind]}n_main`
      );
      this.minNeedle[ind] = document.getElementById(
        `${this.indicators[ind]}n_min`
      );
      this.maxNeedle[ind] = document.getElementById(
        `${this.indicators[ind]}n_max`
      );

      //initialize indicators at some location (will be overwritten as soon as PLC data comes in)
      // this.mainNeedleVal[ind] = - Math.random() * 100;
      this.mainNeedleVal[ind] = -0;
      this.minNeedleVal[ind] = -0;
      this.maxNeedleVal[ind] = -0;
    }

    // miscellaneous
    this.angleBlackBorder = 22.5; // [deg] from bottom line upwards
    this.angleGrayBorder = 45; // [deg] from bottom line upwards
    this.angles = [90, this.angleBlackBorder, this.angleGrayBorder];
    this.ids = ["c10", "c12", "c13"];
    this.ticksPosition = [-100, -75, -50, -25, 0, 25, 50, 75, 100];
    this.numbers = [100, 75, 50, 25, 0, -25, -50, -75, -100];

    this.dummy = 0;
    this.DrawAll();
  }

  DrawAll() {
    // all logic regarding step# and priority status
    // now this is a legacy thing since we only draw one indicator.
    for (let x = 0; x < this.indicators.length; x++) {
      this.container = document.getElementById(
        `${this.indicators[x]}container`
      );
      this.container.classList.add("hidden");

      if (this.currentStep < 3) {
        // draw none
        this.wrapperLeft.style.height = "calc(280px * 0.001 * var(--scaling))";
        this.wrapperLeft.style.backgroundColor = `rgba(0, 0, 0, ${
          this.dummy / 200
        })`;
      } else if (this.currentStep >= 3) {
        let showWidget = false;

        if (
          this.indexOfIndicator == 1 ||
          this.indexOfIndicator == 2 ||
          this.indexOfIndicator == 3
        ) {
          showWidget = true;
        }
        if (this.currentStep >= 4) {
          showWidget = true;
        }

        // draw widget
        if (showWidget) {
          this.DrawOne(x);
          this.wrapperLeft.style.backgroundColor = `rgba(0, 0, 0, ${
            0.49 + this.dummy / 200
          })`;
          this.wrapperLeft.style.height = "calc(280px * 2 * var(--scaling))";
          this.container.classList.remove("hidden");
        }
      }
    }
  }

  DrawOne(ind) {
    this.numbersLuffingContainer[ind].replaceChildren();

    this.mainNeedle[ind].style.backgroundColor = "black";
    this.mainNeedle[ind].style.transform = `rotate(${
      (this.mainNeedleVal[ind] * 90) / 100
    }deg)`;
    this.minNeedle[ind].style.transform = `rotate(${
      (this.minNeedleVal[ind] * 90) / 100
    }deg)`;
    this.maxNeedle[ind].style.transform = `rotate(${
      (this.maxNeedleVal[ind] * 90) / 100
    }deg)`;

    this.mainNeedle[ind].style.left = `${243.5 * this.scalingFactor}px`;
    this.minNeedle[ind].style.left = `${243.5 * this.scalingFactor}px`;
    this.maxNeedle[ind].style.left = `${243.5 * this.scalingFactor}px`;

    // Draw Dial
    this.circleDial[ind].style.width = `${55 * this.scalingFactor}px`;
    this.circleDial[ind].style.height = `${55 * this.scalingFactor}px`;
    this.circleDial[ind].style.border = "0px";
    this.circleDial[ind].style.clipPath =
      "polygon(0% 0%, 100% 0%, 100% 60%, 0% 60%)";
    this.circleDial[ind].style.top = `${this.scalingFactor * 242.7}px`;
    this.circleDial[ind].style.backgroundColor = "black";
    this.circleDial[ind].style.left = `${this.scalingFactor * 217}px`;

    // add titles
    // const textElement = document.createElement("div");
    // textElement.className = "number";
    // textElement.textContent = this.indicatorTitles[ind] + "";
    // textElement.style.fontSize = `${45 * this.scalingFactor}px`;
    // textElement.style.left = `${10 * this.scalingFactor}px`;
    // textElement.style.whiteSpace  = `nowrap`;
    // textElement.style.top = `${-5 * this.scalingFactor}px`;
    // this.numbersLuffingContainer[ind].appendChild(textElement);

    this.htmlNameOffIndicator.innerText = this.indicatorTitles[ind];

    // Add Numbers
    this.numbers.forEach((num) => {
      const numberElem = document.createElement("div");
      numberElem.className = "number";
      numberElem.textContent = -num;

      const angle = ((num + 100) * 180) / 200;
      const radians = (angle * Math.PI) / 180;

      let zeroOffset = 0;
      if (num == 0) {
        zeroOffset = 29 * this.scalingFactor;
      }
      const x =
        215 * this.scalingFactor +
        240 * this.scalingFactor * Math.cos(radians) +
        zeroOffset;
      const y =
        255 * this.scalingFactor - 215 * this.scalingFactor * Math.sin(radians);

      numberElem.style.left = `${x}px`;
      numberElem.style.top = `${y}px`;

      if (
        num != 75 &&
        num != 25 &&
        num != -25 &&
        num != -75
      ) {
        this.numbersLuffingContainer[ind].appendChild(numberElem);
      }
    });
    // Add Ticks
    this.numbers.forEach((num) => {
      const markElem = document.createElement("div");
      markElem.className = "marker";
      const angle = (num * 180) / 200;
      markElem.style.transform = `rotate(${angle}deg)`;
      this.numbersLuffingContainer[ind].appendChild(markElem);
    });

    // DrawArcs
    //   //takes in circle ids and angle up to which the shaded gray and black areas are to appear.
    for (let i = 0; i < this.ids.length; i++) {
      let circleArc = document.getElementById(
        this.indicators[ind] + this.ids[i]
      );
      if (i % 3 == 1) {
        circleArc.style.border =
          "var(--border-width) solid var(--secondaryBorder)";
        if (Math.abs(this.mainNeedleVal[ind]) >= 50) {
          circleArc.style.borderColor = "red";
        }
      } else if (i % 3 == 2) {
        circleArc.style.border =
          "var(--border-width) solid var(--terciaryBorder)";
        if (Math.abs(this.mainNeedleVal[ind]) >= 50) {
          circleArc.style.borderColor = "yellow";
        }
      } else {
        //
        // circleArc.style.border =
        //   "calc(var(--border-width) + var(--scaling) * 5px) solid black";
        // circleArc.style.width = "calc(var(--circle-diameter) * .98";
        // circleArc.style.height = "calc(var(--circle-diameter) * .98";
        // circleArc.style.top = "calc(78px * var(--scaling))";
        // circleArc.style.transform = "scale(1.2)";
      }
      // adds extra corner to polygon if angle exceeds 45 deg.
      if (this.angles[i] > 45) {
        circleArc.style.clipPath = `polygon(
            50% 50%,
            0% ${this.offsetfromHalf}%,
            0% 0%,
            ${50 * (1 - Math.tan(((90 - this.angles[i]) * Math.PI) / 180))}% 0%,
            50% 50%,
            ${50 * (1 + Math.tan(((90 - this.angles[i]) * Math.PI) / 180))}% 0%,
            100% 0%,
            100% ${this.offsetfromHalf}%,
            50% 50%`;
      } else {
        circleArc.style.clipPath = `polygon(
          50% 50%,
          0% ${this.offsetfromHalf}%,
          ${50 * (1 - Math.tan(((90 - this.angles[i]) * Math.PI) / 180))}% 0%,
          50% 50%,
          ${50 * (1 + Math.tan(((90 - this.angles[i]) * Math.PI) / 180))}% 0%,
          100% ${this.offsetfromHalf}%,
          50% 50%`;
      }
    }
  }

  update(value, data) {
    this.dummy++;
    if (this.dummy > 2) {
      this.dummy = 0;
    }

    // this.currentStep = this.selectValue(data, this.wdStepNum);

    this.mainNeedleVal[this.df.pushx] = this.selectValue(data, this.wdPosition);
    this.minNeedleVal[this.df.pushx] = this.selectValue(
      data,
      this.wdPosition
    );
    this.maxNeedleVal[this.df.pushx] = this.selectValue(
      data,
      this.wdPosition
    );

    this.wrapperLeft.style.backgroundColor = `rgba(0, 0, 0, ${
      this.dummy / 100
    })`;

    this.DrawAll();
  }

  render() {}
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
