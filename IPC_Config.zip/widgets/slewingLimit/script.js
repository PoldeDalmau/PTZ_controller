class Component extends BaseComponent 
{
    constructor(context, width, height) 
    {
        super();
        this.themes = ["bright", "day", "dusk", "night"];

        this.valuePath = config.get('widget.Data selector', null);
        this.colorValuePath = config.get('widget.Color', null);

        this.Angle = config.get('widget.Angle');
        this.Orientation = config.get('widget.orientation');

        const rudder = document.getElementById("rudder");

        if(this.Orientation == 'up')
        {
            rudder.clipAngle = -this.Angle;
            rudder.rudderAngle = 180;
            rudder.rudderSetPointAngle = 180;
            this.ra = 180;
            this.sp = 180;
        }else
        {
            rudder.clipAngle = this.Angle;
            rudder.rudderAngle = 0;
            rudder.rudderSetPointAngle = 0;
        }
        
        
        this.increasing = true;
        
    }
        

    updateRudder(angle, setPoint)
    {
        rudder.rudderAngle = angle;
        rudder.rudderSetPointAngle = setPoint;
    }

    demo() 
    {
        if(this.Orientation == 'up')
        {
            if (this.increasing) 
            {
                this.ra++;
                this.sp--;
                if (this.ra >= 360-this.Angle) 
                {
                    this.increasing = false;
                }
            } else 
            {
                this.sp++;
                this.ra--;
                if (this.ra <= this.Angle) 
                {
                    this.increasing = true;
                }
            }
        }else
        {
            if (this.increasing) 
            {
                this.ra++;
                this.sp--;
                if (this.ra >= this.Angle) 
                {
                    this.increasing = false;
                }
            } else 
            {
                this.sp++;
                this.ra--;
                if (this.ra <= -this.Angle) 
                {
                    this.increasing = true;
                }
            }
        }

        setInterval(this.demo, 200);
    }

    update(value, data)
    {
        let demoVal = 0;//this.selectValue(data, this.demoValuePath);
        if(demoVal)
        {
            this.demo();
            this.updateRudder(this.ra, this.sp); // Update both vertical and horizontal gauges

        }else
        {
            let rudderAngle = this.selectValue(data, this.valuePath);
            if(this.Orientation == 'up')
            {
                rudderAngle = 180 + rudderAngle
            }
            this.updateRudder(rudderAngle, 180)
        }

        let theme = document.getElementById("test");
        let index = this.selectValue(data, this.colorValuePath);
        let colorIndex = index % 4;
        theme.setAttribute("theme", this.themes[colorIndex]);
    }

    render()
    {

    }
    
}
registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);        