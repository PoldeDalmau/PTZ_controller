﻿class Component {
    constructor(platform, width, height) {
        this.max = 100;
        this.min = 0;
        this.range = this.max - this.min;

        this.regions = [
            {
                min: 0,
                max: 70,
                color: [0.0, 0.8, 0.0, 0.6]
            },
            {
                min: 70,
                max: 85,
                color: [0.8, 0.8, 0.0, 0.6]
            },
            {
                min: 85,
                max: 100,
                color: [0.8, 0.0, 0.0, 0.6]
            }
        ];

        this.resize(platform, width, height);

        /*var div = document.getElementsByClassName('tickText')[0];
        var styles = getComputedStyle(div);
        console.log(styles);
        console.log(styles.fontSize);
        console.log(styles.color);
        */
    }
    
    resize(platform, width, height) {
        if (width >=  height) {
            width = height;
        } else {
            height = width;
        }

        this.background = Stardust.mark.create(Stardust.mark.rect(), platform);
        this.gauge = Stardust.mark.create(Arc, platform);
        this.axis = Stardust.mark.create(Arc, platform);
        this.tick = Stardust.mark.create(Stardust.mark.line(), platform);
        this.tickText = Stardust.mark.createText("2d", platform);

        this.background.attr("p1", [0, 0]);
        this.background.attr("p2", [width, height]);
        this.background.attr("color", [0.0, 0.15, 0.3, 0.6]);
        this.background.data([0]);

        this.axis.attr("center", [width / 2.0, height * 0.5]);
        this.axis.attr("theta1", -0.8 * Math.PI);
        this.axis.attr("theta2", 0.8 * Math.PI);
        this.axis.attr("inner", height * 0.38);
        this.axis.attr("outer", height * 0.39 - 5);
        this.axis.attr("color", [0.8, 0.8, 0.8, 0.6]);
        this.axis.data([0]);

        const tickInner = height * 0.36 - 5;
        const tickOuter = height * 0.38333;
        const tickAngle = v => (-0.8 + (1.6 * (v / this.range))) * Math.PI;
        this.tick.attr("p2", v => [(width / 2.0) + Math.sin(tickAngle(v)) * tickInner, (height * 0.5) - Math.cos(tickAngle(v)) * tickInner]);
        this.tick.attr("p1", v => [(width / 2.0) + Math.sin(tickAngle(v)) * tickOuter, (height * 0.5) - Math.cos(tickAngle(v)) * tickOuter]);
        this.tick.attr("color", [0.8, 0.8, 0.8, 0.6]);
        this.tick.attr("width", 0.01 * height - 5);
        const tickPoints = [];
        tickPoints.push(this.regions[0].min);
        for (let i = 0; i < this.regions.length; i++) {
            tickPoints.push(this.regions[i].max);
        }
        this.tick.data(tickPoints);

        const tickTextRadius = 0.36 * height - 20;
        this.tickText.attr("position", v => [(width / 2.0) + Math.sin(tickAngle(v)) * tickTextRadius, (height * 0.5) - Math.cos(tickAngle(v)) * tickTextRadius]);
        this.tickText.attr("color", [0.8, 0.8, 0.8, 0.6]);
        this.tickText.attr("text", v => v.toFixed(0));
        this.tickText.attr("fontSize", 15 + height/200.0);
        this.tickText.attr("fontWeight", 600.0);
        this.tickText.attr("alignX", 0.5);
        this.tickText.attr("alignY", 0.5);
        this.tickText.data(tickPoints);
        
        this.gauge.attr("center", [width / 2.0, height * 0.5]);
        this.gauge.attr("theta1", -0.8 * Math.PI);
        this.gauge.attr("theta2", v => (-0.8 + (v/this.range) * 1.6) * Math.PI);
        this.gauge.attr("inner", height * 0.4);
        this.gauge.attr("outer", height * 0.45);
        var regions = this.regions;
        this.gauge.attr("color", v => {
            return regions.find(r => r.min <= v && r.max >= v).color;
        });
        this.gauge.data([0]);
    }

    // TODO: Change this to accept a Object full of data & select the appropriate part(s)
    update(value) {
        var v = 50 + (50 * Math.sin(value / 4000));
        this.gauge.data([v]);
    }

    render() {
        this.background.render();
        this.gauge.render();
        this.axis.render();
        this.tick.render();
        this.tickText.render();
    }
}

registerComponent(Component, COMPONENT_TYPES.STARDUST);