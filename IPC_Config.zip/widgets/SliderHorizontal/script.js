class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    this.scalingFactor = getComputedStyle(document.body).getPropertyValue(
      "--scaling"
    );

    this.wdNameOfSlider = config.get("widget.NameOfWidget", null);
    this.wdUnitOfSlider = config.get("widget.UnitOfWidget", null);
    // get PLC data
    this.wdPosition = config.get("widget.Position", null);
    this.wdLowSpeedMinusArea = config.get("widget.LowSpeedMinusArea", null);
    this.wdLimitMinus = config.get("widget.LimitMinus", null);
    this.wdLimitPlus = config.get("widget.LimitPlus", null);
    this.wdLowSpeedPlusArea = config.get("widget.LowSpeedPlusArea", null);
    this.wdStartPosition = config.get("widget.StartPosition", null);
    this.wdEndPosition = config.get("widget.EndPosition", null);

    // get HTML elements
    this.nameOfSlider = document.getElementById("nameOfSlider");
    this.container = document.getElementById("container");
    this.pointerBlock = document.getElementById("pointerBlock");
    this.containerBar = document.getElementById("containerPointer");
    this.valueForBar = document.getElementById("valueForBar");

    // this.containerBar = document.getElementById("containerLuffing");
    this.progBar = document.getElementById("progressBarLuffing");

    // conatiner
    this.namesContainers = ["containerPointer"];
    this.rangesCointainer = [this.rangesContLuffing];

    this.colorsBar = [`rgb(190, 190, 190. 0.5)`, `rgb(215, 217, 217, 0.5)`, "rgb(255, 255, 255, 1)", `rgb(215, 217, 217, 0.5)`, `rgb(190, 190, 190. 0.5)`];

    //
    this.lengthOfBar = 200;
    this.lengthOfLimits = 186;

    // width in pixels
    this.firstWidth = 16;
    this.secondWidth = 30;
    this.thirdWidth = 108;
    this.fourthWidth = 30;
    this.fifthWidth = 16;

    this.widthBarsLuffing = [
      this.firstWidth,
      this.secondWidth,
      this.thirdWidth,
      this.fourthWidth,
      this.fifthWidth,
    ];

    this.dummy = 0;

    this.valueBar = 90;
    this.startPosition = -100;
    this.endPosition = 100;
    this.diffStartEnd = this.endPosition - this.startPosition;
    
      
    this.containerBar.replaceChildren();
    this.progBar.replaceChildren();
    this.AddColorBlocks();
    this.AddBars();
    this.AddNumbers();
    this.Draw();
  }

  AddPositionPointer() {
    let varName = `colorBlock${i}`;
    const node = document.createElement(varName);
    node.style.position = "absolute";
    node.style.top = `${0 * this.scalingFactor}px`;
    node.style.width = `${this.widthBarsLuffing[i] * this.scalingFactor}px`;
    node.style.height = `100%`;
    node.style.left = `${firstPos * this.scalingFactor}px`;
    node.style.backgroundColor = this.colorsBar[i];

    firstPos += this.widthBarsLuffing[i];

    this.progBar.appendChild(node);
  }

  AddColorBlocks() {
    let firstPos = 0;
    for (let i = 0; i < 5; i++) {
      let varName = `colorBlock${i}`;
      const node = document.createElement(varName);
      node.style.position = "absolute";
      node.style.top = `${0 * this.scalingFactor}px`;
      node.style.width = `${this.widthBarsLuffing[i] * this.scalingFactor}px`;
      node.style.height = `100%`;
      node.style.left = `${firstPos * this.scalingFactor}px`;
      node.style.backgroundColor = this.colorsBar[i];

      firstPos += this.widthBarsLuffing[i];

      this.progBar.appendChild(node);
    }
  }

  AddBars() {
    let range = this.endPosition - this.startPosition;
    let firstPos = 4.5;
    let multiply = 1;

    if (range >= 100){
      multiply = 3;
    }

    for (let i = this.startPosition; i < this.endPosition + 1; i++) {
      let varName = `smallBars${i}`;
      const node = document.createElement(varName);
      node.style.position = "absolute";
      if (i % (10 * multiply) == 0) {
        node.style.top = `${15 * this.scalingFactor}px`;
        node.style.width = `${1 * this.scalingFactor}px`;
        node.style.height = `${14 * this.scalingFactor}px`;
        node.style.left = `${firstPos * this.scalingFactor}px`;
      } else if (i % (5 * multiply) == 0) {
        node.style.top = `${19 * this.scalingFactor}px`;
        node.style.width = `${1 * this.scalingFactor}px`;
        node.style.height = `${10 * this.scalingFactor}px`;
        node.style.left = `${firstPos * this.scalingFactor}px`;
      } else if (i % (1 * multiply) == 0) {
        node.style.top = `${22 * this.scalingFactor}px`;
        node.style.width = `${1 * this.scalingFactor}px`;
        node.style.height = `${7 * this.scalingFactor}px`;
        node.style.left = `${firstPos * this.scalingFactor}px`;
      }

      node.style.backgroundColor = "black";

      firstPos += 186 / range;

      this.containerBar.appendChild(node);
    }
  }

  AddNumbers() {
    let range = this.endPosition - this.startPosition;
    let interval;
    if (range > 150) {
      interval = 30;
    }
    else if (range > 50) {
      interval = 10;
    } else {
      interval = 5;
    }
    let firstPos;
    for (let j = 0; j < this.namesContainers.length; j++) {
      firstPos = -1;
      for (let i = this.startPosition; i < this.endPosition + 1; i++) {
        let varName = `number${i}n${this.namesContainers[j]}`;
        let offset = 3; // shifts numbers a bit to the left to ensure they stay inside the container
        const node = document.createElement(varName);
        if (i % interval == 0) {
          // || i == this.startPosition || i == this.endPosition){
          node.style.position = "absolute";
          node.style.top = `${2 * this.scalingFactor}px`;
          node.style.width = `${20 * this.scalingFactor}px`;
          node.style.height = `${15 * this.scalingFactor}px`;
          node.style.left = `${(firstPos - offset) * this.scalingFactor}px`;
          node.style.fontSize = `${10 * this.scalingFactor}px`;
          node.style.textAlign = "center";
          node.textContent = Math.round(i);
        }

        firstPos += 183 / range;

        this.containerBar.appendChild(node);
      }
    }
  }

  Draw() {
    this.posPointer =
    (this.lengthOfLimits / this.diffStartEnd) *
      (this.valueBar - this.startPosition) +
    1.1 * this.scalingFactor;
    // this.containerPointer.textContent = `${this.posPointer * this.scalingFactor -1}px`;
    this.pointerBlock.style.left = `${this.posPointer * this.scalingFactor -1}px`;
    // this.valueForBar.textContent = Math.round(this.valueBar) + this.wdUnitOfSlider;
    this.pointerBlock.textContent = Math.round(this.valueBar);
    this.nameOfSlider.textContent = this.wdNameOfSlider;
    this.nameOfSlider.style.lineHeight = '20px';
    this.container.style.backgroundColor = `rgb(0,0,0, ${
      0.5 + this.dummy / 200
    })`;
  }

  update(value, data) {
    this.containerBar.replaceChildren();
    this.progBar.replaceChildren();

    this.valueBar = this.selectValue(data, this.wdPosition);

    let vLowSpeedMinusArea = this.selectValue(data, this.wdLowSpeedMinusArea);
    let vLimitMinus = this.selectValue(data, this.wdLimitMinus);
    let vLimitPlus = this.selectValue(data, this.wdLimitPlus);
    let vLowSpeedPlusArea = this.selectValue(data, this.wdLowSpeedPlusArea);

    this.startPosition = this.selectValue(data, this.wdStartPosition);
    this.endPosition = this.selectValue(data, this.wdEndPosition);
    this.diffStartEnd = this.endPosition - this.startPosition;

    this.firstWidth =
      (this.lengthOfBar * (vLowSpeedMinusArea - this.startPosition)) /
      this.diffStartEnd;

    this.secondWidth =
      (this.lengthOfBar * (vLimitMinus - vLowSpeedMinusArea)) /
      this.diffStartEnd;

    this.thirdWidth =
      (this.lengthOfBar * (vLimitPlus - vLimitMinus)) / this.diffStartEnd;

    this.fourthWidth =
      (this.lengthOfBar * (vLowSpeedPlusArea - vLimitPlus)) / this.diffStartEnd;

    this.fifthWidth =
      (this.lengthOfBar *
        (this.startPosition.endPosition - vLowSpeedPlusArea)) /
      this.diffStartEnd;

    this.dummy++;
    if (this.dummy > 2) {
      this.dummy = 0;
    }

    this.Draw();
    this.AddBars();
    this.AddNumbers();
    this.AddColorBlocks();
  }

  render() {}
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
