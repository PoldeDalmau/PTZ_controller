﻿class Component extends BaseComponent  {
    constructor(context, width, height) {
        super();
        this.orientation = config.get('widget.orientation', 'up');
        this.valuePath = config.get('widget.selector', null);
        this.ratio = 0.3;

        this.backgroundColor = config.get('colors.background', config.get('widget.backgroundColor', 'black'));
        this.foregroundColor = config.get('colors.foreground', config.get('widget.foregroundColor', 'white'));

        this.valueDirty = false;
        this.skippedRenders = 0;

        // TODO: Set points?
        // TODO: Requested value?
        // TODO: Value markers


        this.regions = [
            {
                min: -1000,
                max: -180,
                color: config.get('colors.danger', config.get('widget.dangerColor', 'red'))
            },
            {
                min: -180,
                max: 180,
                color: config.get('colors.positive', config.get('widget.positiveColor', 'green'))
            },
            {
                min: 180,
                max: 12000,
                color: config.get('colors.danger', config.get('widget.dangerColor', 'red'))
            }
        ];

        this.leftSeries = {
            regions: this.regions,
            ticks: [parseInt(config.get('widget.min', 0)), 0, parseInt(config.get('widget.max', 100))],
            width: 1.0,
            minValue: parseInt(config.get('widget.min', 0)),
            maxValue: parseInt(config.get('widget.max', 100)),
            justify: 'left'
        };

        this.resize(context, width, height);
    }
    
    resize(context, width, height) {
        this.fontSize = this.getFontSize(width, height);
        this.margin = this.getMargin(width, height);

        const ratio = width / height;
        if(this.orientation === 'up' || this.orientation === 'down'){
            this.lineWidthVertical = 0.01;
            this.lineWidthHorizontal = this.lineWidthVertical * ratio;
        }else{
            this.lineWidthHorizontal = 0.01;
            this.lineWidthVertical = this.lineWidthHorizontal / ratio;
        }

        this.width = width;
        this.height = height;
        this.context = context;


        this.setupBackground(window.innerWidth, window.innerHeight);

        // Render the background
        this.backgroundContext.fillStyle = this.backgroundColor;

        this.backgroundContext.beginPath();
        this.backgroundContext.rect(0, 0, window.innerWidth, window.innerHeight);
        this.backgroundContext.fill();

        this.renderAxis(this.leftSeries, 'left');

        //this.renderAxis(this.rightSeries, 'right');
    }

    applyTransform(context){
        context.setTransform(1, 0, 0, 1, 0, 0);
        if(this.orientation === 'up') {
            context.translate(this.margin, this.margin);
            context.scale((this.width - 2 * this.margin) / 1, (this.height - 2 * this.margin) / 1);
        }else if(this.orientation === 'down'){
            context.translate(this.margin, this.height - this.margin);
            context.scale((this.width - 2 * this.margin) / 1, (this.height - 2 * this.margin) / -1);
        }

        if(this.orientation === 'right'){
            context.translate(0, this.height);
            context.rotate(-Math.PI/2);
            context.translate(this.margin, this.width - this.margin);
            context.scale((this.height - 2 * this.margin) / 1, (this.width - 2 * this.margin) / -1);
        }else if(this.orientation === 'left'){
            context.translate(0, this.height);
            context.rotate(-Math.PI/2);
            context.translate(this.margin, this.margin);
            context.scale((this.height - 2 * this.margin) / 1, (this.width - 2 * this.margin) / 1);
        }
    }

    update(value, data) {
        if(this.valuePath){
            this.v = this.selectValue(data, this.valuePath);
            this.valueDirty = true;
        }
        //this.z = (data.orientationAbsolute || {}).beta || 0;
    }

    renderGauge(series, value) {
        if(!this.valueDirty && this.skippedRenders < 50.0/this.frameTime) {
            this.skippedRenders++;
            return;
        }

        const context = this.context;
        context.save();
        this.applyTransform(context);
        context.beginPath();

        console.log(0.5, 1.0 + series.minValue/(series.maxValue - series.minValue), 0.5, (-value)/(series.maxValue - series.minValue));
        //context.rect(0.5, 1.0 + series.minValue/(series.maxValue - series.minValue), 0.5, (-value)/(series.maxValue - series.minValue));
        if(series.minValue > 0){
            context.rect(0.5, 1.0, 0.5, (series.minValue-value)/(series.maxValue - series.minValue));
        }else{
            context.rect(0.5, 1.0 + series.minValue/(series.maxValue - series.minValue), 0.5, (-value)/(series.maxValue - series.minValue));
        }

        const currentRegion = series.regions.find(r => r.min <= (value || 0) && r.max >= (value || 0)) || series.regions[0] || { color: 'black'};
        context.fillStyle = currentRegion.color;
        context.fill();
        context.restore();

        this.valueDirty = false;
        this.skippedRenders = 0;
    }

    renderAxis(series, position) {
        const context = this.backgroundContext;
        this.applyTransform(context);

        if(series.justify === 'right'){
            context.translate(1, 0);
            context.scale(-1, 1);
        }

        context.beginPath();

        context.moveTo(0.500, 0);
        context.lineTo(0.500, 1.000);
        context.lineWidth = this.orientation === 'up' || this.orientation === 'down' ? this.lineWidthVertical : this.lineWidthHorizontal;
        context.strokeStyle = this.foregroundColor
        context.stroke();

        if (!series.ticks) {
            return;
        }

        context.beginPath();
        context.font = `bold ${this.fontSize}px Sans-serif`;
        if (this.orientation === 'up' || this.orientation == 'down') {
            if (series.justify === 'right') {
                context.textAlign = 'left';
            }else{
                context.textAlign = 'right';
            }
        }else{
            context.textAlign = 'center';
        }

        context.fillStyle = this.foregroundColor;

        for (var i = 0; i < series.ticks.length; i++) {
            const tickY = (series.maxValue - series.ticks[i])/(series.maxValue - series.minValue);

            // Larger zero tick
            let tickWidth = series.ticks[i] === 0 ? 0.3 : 0.2;

            context.save();
            if(this.orientation === 'left' || this.orientation === 'right'){
                context.rotate(Math.PI/2);
                const t = context.getTransform();
                context.scale(1/t.a, 1/t.d); // Reset scale so font sizes are in px
                const j = this.justify === 'left' ? 1 : -1;
                context.fillText(series.ticks[i].toString(), tickY * t.a, Math.sign(t.d) * j * 0.1 * this.height); // Calculate position in Canvas X/Y
            }else{
                const t = context.getTransform();
                context.scale(1/t.a, 1/t.d);
                const j = this.justify === 'left' ? -1 : 1; // Needs to be inverted
                context.fillText(series.ticks[i].toString(),Math.sign(t.a) * j * 0.1 * this.width, tickY * t.d + this.fontSize/3);
            }

            context.restore();
            context.moveTo(0.5, tickY);
            context.lineTo(0.5 - tickWidth, tickY);
        }

        context.lineWidth = this.orientation === 'up' || this.orientation === 'down' ? this.lineWidthHorizontal : this.lineWidthVertical;
        context.strokeStyle = this.foregroundColor;
        context.stroke();
    }

    render() {
        this.renderGauge(this.leftSeries, this.v);
    }
}

registerComponent(Component, COMPONENT_TYPES.CANVAS2D);