class Component extends BaseComponent {
    constructor(context, width, height) {
        super();

        //get plc data. 'widget.Data' is  taken from plc_data_block.json.
        // this.dataValuePath = config.get('widget.Data', null);
        
        this.canvas = document.getElementById('canvas');
        this.ctx = this.canvas.getContext('2d');

        this.slider = document.getElementById('xSlider');
        this.sliderValue = 45;
        this.slider.addEventListener('input', () => {
            this.sliderValue = this.slider.value;
            this.Draw();
        });

        this.Draw();
    }

    calculateCoordinates(angleDegrees, length) {
        const angleRadians = angleDegrees * (Math.PI / 180);
        
        const x = length * Math.cos(angleRadians);
        const y = length * Math.sin(angleRadians);
        
        return { x, y };
    }

    createDynamicDiv(canvas, number, x, y) {
        const div = document.createElement('div');
        div.id = 'dynamicDiv';
        div.textContent = number;

        const canvasRect = canvas.getBoundingClientRect();

        // Set the position of the div relative to the canvas
        div.style.left = `${canvasRect.left + x}px`;
        div.style.top = `${canvasRect.top + y}px`;

        // Add the div to the body (positioned over the canvas)
        document.body.appendChild(div);
    }

    drawCircle(x, y, radius, startAngle, stopAngle) {
        this.ctx.beginPath();

        this.ctx.arc(x, y, radius, startAngle * (Math.PI / 180), Math.PI - stopAngle * (Math.PI / 180));

        this.ctx.strokeStyle = 'red';
        this.ctx.lineWidth = 2;

        this.ctx.stroke();
    }

    Draw() {
        // Set canvas dimensions to match the image dimensions
        this.canvas.width = 600;
        this.canvas.height = 600;

        let colorBlack = 'black';
        let colorWhite = 'white';

        this.ctx.fillStyle = "white";
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        let angleLine = 45;        

        let x = this.canvas.width / 1.5;
        let y = this.canvas.height / 1.4;

        let startPointX = 80;
        let startPointY = 600;

        let lenghtBaseLine = 200;
        let lenghtFirstLine = 200;
        let lenghtThirdLine = 200;

        let angleLineTwo = 45;
        let angleLineThreee = 90;
        let angleLineThree = angleLineTwo + angleLineThreee - 180;
        
        this.ctx.strokeStyle = colorBlack;
        this.ctx.lineWidth = 2;

        // base line
        this.ctx.beginPath();
        this.ctx.moveTo(startPointX, startPointY);
        this.ctx.lineTo(startPointX + lenghtBaseLine, startPointY);
        this.ctx.stroke();
        
        // second line
        const coordinatesSecondline = this.calculateCoordinates(angleLineTwo, lenghtFirstLine);
        this.createDynamicDiv(this.canvas, angleLineTwo, 200, 200)
        let coordX2 = startPointX + coordinatesSecondline.x;
        let coordY2 = startPointY - coordinatesSecondline.y

        this.ctx.beginPath();
        this.ctx.moveTo(startPointX, startPointY);
        this.ctx.lineTo(coordX2, coordY2);
        this.ctx.strokeStyle = 'red';
        this.ctx.stroke();

        // second line
        const coordinatesThirdLine = this.calculateCoordinates(angleLineThree, lenghtThirdLine);
        this.createDynamicDiv(this.canvas, sliderValue, 200, 200)

        this.ctx.beginPath();
        this.ctx.moveTo(coordX2, coordY2);
        this.ctx.lineTo(coordX2 + coordinatesThirdLine.x, coordY2 - coordinatesThirdLine.y);
        this.ctx.strokeStyle = 'red';
        this.ctx.stroke();

        this.drawCircle(coordX2, coordY2, 30, 360 - angleLineThree, angleLineTwo);
        this.drawCircle(startPointX, startPointY, 30, 360-angleLineTwo, 180);
    }



    update(value, data) {
        // Update function logic
    }

    render() {
        // Render function logic
    }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
