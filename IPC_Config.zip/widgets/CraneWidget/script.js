class Component extends BaseComponent {
  constructor(context, width, height) {
    super();

    // get PLC data
    this.wdBoomAngle = config.get("widget.BoomAngle", null);
    this.wdKnuckleAngle = config.get("widget.KnuckleAngle", null);

    // this.slider1 = document.getElementById("sliderAngle1");
    // this.slider2 = document.getElementById("sliderAngle2");

    this.testen = document.getElementById("angleCircle");

    this.angleBoom = 0;
    this.angleKnuckle = 70;

    //     this.slider1.addEventListener('input', () => {
    //     this.angleBoom = parseInt(this.slider1.value, 10);
    //     this.Draw();
    // });

    // this.slider2.addEventListener('input', () => {
    //     this.angleKnuckle = parseInt(this.slider2.value, 10);
    //     this.Draw();
    // });

    let incrementBoomKnuckle = [true, true]
    let sliderValues = [this.angleBoom, this.angleKnuckle]

    setInterval(() => {
        incrementBoomKnuckle.forEach(function (value, i) {
            if (incrementBoomKnuckle[i]) {
                sliderValues[i]++;
                if (sliderValues[i] >= 110) {
                    incrementBoomKnuckle[i] = false;
                }
            } else {
                sliderValues[i]--;
                if (sliderValues[i] <= 0) {
                    incrementBoomKnuckle[i] = true;
                }
            }
        });
        this.Draw();

        this.angleBoom = sliderValues[0];
        this.angleKnuckle = sliderValues[1];
    }, 100);

    this.Draw();
  }

  calculateCoordinates(angleDegrees, length) {
    const angleRadians = angleDegrees * (Math.PI / 180);

    const x = length * Math.cos(angleRadians);
    const y = length * Math.sin(angleRadians);

    return { x, y };
  }

  updateTextCanvas(coordX, coordY, text) {
    this.paragraph.style.left = coordX + "px";
    this.paragraph.style.top = coordY + "px";
    this.paragraph.textContent = text;
  }

  updateText(nameOfElement, coordX, coordY, text) {
    const element = document.getElementById(nameOfElement);

    element.style.left = coordX + "px";
    element.style.top = coordY + "px";
    element.innerText = text;
  }

  updateElement(nameOfElement, leftCoor, topCoor, angleDegr) {
    const element = document.getElementById(nameOfElement);
    const newLeft = leftCoor + "px";
    const newTop = topCoor + "px";
    const rotation = "rotate(" + angleDegr + "deg)";

    element.style.left = newLeft;
    element.style.top = newTop;
    element.style.transform = rotation;
  }

  updateCircle(nameOfElement) {
    const angle = document.getElementById("angleInput").value;
    const circle = document.getElementById(nameOfElement);
    const clipPathValue = `polygon(50% 50%, 50% 0%, ${
      50 + 50 * Math.cos((Math.PI * angle) / 180)
    }% ${50 - 50 * Math.sin((Math.PI * angle) / 180)}%, 50% 50%)`;

    // Update the clip-path property to create the desired visible border
    circle.querySelector("::before").style.clipPath = clipPathValue;
  }

  addText(text, x, y) {
    this.texts.push({ text, x, y });
  }

  drawCircle(x, y, radius, startAngle, stopAngle) {
    this.ctx.beginPath();

    this.ctx.arc(
      x,
      y,
      radius,
      startAngle * (Math.PI / 180),
      Math.PI - stopAngle * (Math.PI / 180)
    );

    this.ctx.strokeStyle = "red";
    this.ctx.lineWidth = 2;

    this.ctx.stroke();
  }

  calculateSide(a, b, angleC) {
    let angleCRad = angleC * (Math.PI / 180);

    let c = Math.sqrt(a * a + b * b - 2 * a * b * Math.cos(angleCRad));
    return c;
  }

  toDegrees(radians) {
    return radians * (180 / Math.PI);
  }

  calculateAngleB(a, b, c) {
    const cosB = (a * a + c * c - b * b) / (2 * a * c);
    const angleB = Math.acos(cosB);

    return this.toDegrees(angleB);
  }

  Draw() {
    const distanceNumberOfCenter = 40;

    const heightBlock = 300;
    const widthBlock = 300;

    const topYCoor = 90;
    const leftXCoor = 60;

    const lenghtOfLine = 78;

    this.updateElement("boomCrane", leftXCoor, topYCoor, -this.angleBoom);
    let coorTopBoomCrane = this.calculateCoordinates(this.angleBoom, lenghtOfLine);

    let angleLineKncuckleCranee = -this.angleKnuckle;
    let angleLineKncuckleCrane =
      -this.angleBoom + angleLineKncuckleCranee - 180;

    // postion of text
    let lenghtOfC = this.calculateSide(
      lenghtOfLine,
      distanceNumberOfCenter,
      180 - this.angleKnuckle / 2
    );
    let angleB = this.calculateAngleB(
      lenghtOfLine,
      distanceNumberOfCenter,
      lenghtOfC
    );
    let coord = this.calculateCoordinates(
      this.angleBoom + angleB,
      lenghtOfC
    );

    this.updateElement(
      "knuckleCrane",
      leftXCoor + coorTopBoomCrane.x,
      topYCoor - coorTopBoomCrane.y,
      angleLineKncuckleCrane
    );

    // this.updateText(
    //   "angleCircle1",
    //   leftXCoor - 10,
    //   topYCoor,
    //   this.angleBoom + "°"
    // );
    // this.updateText(
    //   "angleCircle2",
    //   leftXCoor - 5 + coord.x,
    //   topYCoor - coord.y,
    //   this.angleKnuckle + "°"
    // );
  }

  update(value, data) {
    this.angleBoom = this.selectValue(data, this.wdBoomAngle);
    this.angleKnuckle = this.selectValue(data, this.wdKnuckleAngle);

    // Update function logic
  }

  render() {
    // Render function logic
  }
}

registerComponent(Component, COMPONENT_TYPES.DATA_ONLY);
