// Get the canvas element and its context
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// Create an image object
const img = new Image();

// Set the image source (replace 'image.png' with the path to your PNG image)
img.src = 'ternarycontour.png';

// When the image is loaded, draw it on the canvas and then draw a cross on top
img.onload = function() {
    // Set canvas dimensions to match the image dimensions
    canvas.width = img.width;
    canvas.height = img.height;
    
    // Draw the image on the canvas
    ctx.drawImage(img, 0, 0);
    
    // Draw a cross on top of the image
    drawCross(ctx, img.width / 2, img.height / 2, 20, 'red');
};

// Function to draw a cross at the specified position
function drawCross(ctx, x, y, size, color) {
    // Set the line color
    ctx.strokeStyle = color;
    // Set the line width
    ctx.lineWidth = 2;
    
    // Draw horizontal line
    ctx.beginPath();
    ctx.moveTo(x - size, y);
    ctx.lineTo(x + size, y);
    ctx.stroke();
    
    // Draw vertical line
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x, y + size);
    ctx.stroke();
}
